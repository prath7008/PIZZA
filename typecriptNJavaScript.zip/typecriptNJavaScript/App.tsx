import './App.css';
import React, { useEffect, useState, MouseEvent, FormEvent, useRef, useMemo, useCallback, createContext, useContext, ReactNode } from 'react';
import WeatherList from './Weather/WeatherList.tsx';


// interface MyContext{
//   count: number,
//   increament: () => void
// }

// interface MyProviderProps {
//   children: ReactNode; // Define children prop
// }


// const UserContext = createContext<null>(null)

// const UserProvider:React.FC<MyProviderProps> = ({children}) => {
//     const [count,setCount] = useState<number>(0)
//     const increament = () => {
//         setCount(prevCount => prevCount + 1);  
//     }
//     const context:MyContext = {
//       count,
//       increament
//     }
//     return <UserContext.Provider value={context}>{children}</UserContext.Provider>
// }

// const useMyContext = () => {

//   const context = useContext(UserContext);
//   return context
// }


// const Child:React.FC = () => {
  
//   const {count,increament} = useMyContext()

//   return(
//     <>
//       <p>{count}</p>
//       <button onClick={increament}>Click Here</button>
//     </>
//   )
// }


const  App:React.FC = () => {
  
  return(
    <>
      {/* <UserProvider>
        <Child/>
       
      </UserProvider> */}
      <WeatherList/>
    </>
  )
}


export default App;
