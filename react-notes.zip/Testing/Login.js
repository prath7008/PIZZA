import React, { useState } from 'react'

const Login = () => {

 const [error,setError] = useState(false);
 const [username,setUsername] = useState("");
 const [password,setPassword] = useState(""); 
 const [user,setUser] = useState({});
 const [loading,setLoading] = useState(false);
 const handleClick = async(event) => {
    event.preventDefault();
    setLoading(true)
    try{
       const data =   await fetch('https://jsonplaceholder.typicode.com/users/1');
       const dataJson = await data.json();
       setUser(dataJson)
       setLoading(false)
    }
    catch(err){
        setError(true)
        setLoading(false)
    }
 }
  return (
    <div className='container'>
        <form>
            <input type='text' placeholder='username' value={username} onChange={e => setUsername(e.target.value)}/>
            <input type='password' placeholder='password' value={password} onChange={e => setPassword(e.target.value)}/>
            <button disabled={!username || !password} onClick={handleClick}>
                {loading ? "please wait" : "Login" }</button>
            <span data-testId="error" 
            style ={{visibility: error ? "visible": "hidden"}}> 
            Something went Wrong</span>
        </form>
    </div>
  )
}

export default Login