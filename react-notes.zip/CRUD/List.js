import React, { useState } from 'react'

const List = () => {
  const itemList = ['prath','rahul','ameya','hritik'];

  const [items,setItem] = useState(itemList);
  const [add,setAddItem] = useState("");
  const [edit,setEditItem] = useState("");
  const [editedIndex,setEditedIndex] = useState("");
  const [search,setSearch] = useState("")

  const handleEditIndex = (index)=> setEditedIndex(index)
  
  const handleEdit = (event) => {
    setEditItem(event.target.value)
  }

  const handleDelete = (index) => {
    const newItems = items.filter((val,ind,arr)=> index !== ind);
    setItem(newItems)
 }

 const handleUpdate = () => {
    const temp = [...items];
    temp[editedIndex] = edit;

    setItem(temp)
    setEditItem("")
    setEditedIndex(null)
 }

 const handleAdd = () => {
    setItem([...items,add])
 }

 const filteredItems =  items.filter((val,ind,arr)=> search === val)

  return (
    <>
    <div>
        <input type='text' placeholder='Enter Text Here' value={search} onChange={(e) => setSearch(e.target.value)}/>
    </div>
    <div>
        <input type='text'  onChange={(e)=>setAddItem(e.target.value)}/>
        <button onClick={handleAdd}>Add</button>
    </div>
    <ul>
        {
        search !== "" && 
             filteredItems?.map((value,index)=>(
                
                <li key = {index}>
                    {index === editedIndex
                        ? 
                        <>
                            <input type='text'
                                value={edit}
                                onChange={handleEdit}
                                placeholder='Enter Text Here'
                            />
                            <button onClick={()=>handleUpdate(index)}>Update</button>     
                            <button onClick={()=>handleDelete(index)}>Delete</button>     
                        </>
                        :
                        <>
                            {value}
                            <button onClick={()=>handleEditIndex(index)}>Edit</button>     
                            <button onClick={()=>handleDelete(index)}>Delete</button>     
                        </> 
                    }
                 </li>
            )
        )}
        {
            search ===  "" &&
            items?.map((value,index)=>(
                
                <li key = {index}>
                {index === editedIndex
                    ? 
                    <>
                        <input type='text'
                            value={edit}
                            onChange={handleEdit}
                            placeholder='Enter Text Here'
                        />
                        <button onClick={()=>handleUpdate(index)}>Update</button>     
                        <button onClick={()=>handleDelete(index)}>Delete</button>     
                    </>
                    :
                    <>
                        {value}
                        <button onClick={()=>handleEditIndex(index)}>Edit</button>     
                        <button onClick={()=>handleDelete(index)}>Delete</button>     
                </> 
                }
            </li>
            )
        )}
    </ul>
    </>
  )
}

export default List