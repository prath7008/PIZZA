import React, { useEffect, useState } from 'react'

const FetchApi = () => {
    const [results,setResult] = useState([]);
    const [isloaded,setLoaded] = useState(false);
    const [error,setError] = useState(null);
    
    useEffect(()=>{

        fetch('https://jsonplaceholder.typicode.com/users')
        .then((res)=>res.json())
        .then((res)=> {console.log(res);setResult(res);setLoaded(true)},
              (error) => {console.log(error);setError(error);setLoaded(true)})
    },[])
    const errorMessage = () => {return <h2>Error Message</h2>}
    const isLoading = () => {return <h2>Loading....</h2>}
    const showData = () => {
        return (
          <>
            <ul>
                {results.length && results.map((result,index)=>(
                    <li key ={result.id}>
                        {result.username}
                    </li>
                )
                )}
            </ul>
          </>
          )
    }
    if(error) return errorMessage()
    return !isloaded ? isLoading() : showData()
}

export default FetchApi