import { useState } from "react"


export default function TodoApp  (){
    const [todos,setTodos] = useState([]);
    const [input,setInput] = useState("");
    
    const [editIndex,setEditIndex] = useState(null);
    const [edit,setEdit] = useState(null);

    const handleAdd = () => {
        setTodos([...todos,input])
    }

    const handleDelete = (index) => {
        const filteredItems = todos.filter((val,ind,arr)=> index!== ind)
        setTodos(filteredItems)
    }

    const handleUpdate = () => {
        const temp = [...todos]
        temp[editIndex] = edit;
        setTodos(temp);
        setEditIndex(null)
        setEdit("")
    }


    return(
        <>
            <div>
                <input type="text" placeholder="Enter Text Here" onChange={(e) => setInput(e.target.value)}/> 
                <button disabled={!input} onClick={handleAdd}>Add</button>
            </div>
            <ul>
                {todos.map((todo,index)=> (
                    <li key ={index}>
                        {index === editIndex ? 
                            <>
                                <input type="text" value={edit} onChange={(e)=>setEdit(e.target.value)}/>
                                <button onClick={()=>handleUpdate(index)}>Update</button>
                                <button onClick={()=>handleDelete(index)}>Delete</button>
                            </>
                            :
                            <>
                            {todo}
                            <button onClick={()=>setEditIndex(index)}>Edit</button>
                            <button onClick={()=>handleDelete(index)}>Delete</button>
                            </>
                        }
                    </li>
                ))}

            </ul>
        </>
    )

}