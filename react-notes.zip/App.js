import logo from './logo.svg';
import './App.css';
import BookingApp from './Component/BookingApp';
import Home from './ContextApi.js/Home';
import ProviderPattern from './Pattern/ProviderPattern';
import ContainerView from './Pattern/ContainerView';
import RenderProp from './Pattern/RenderProp';
import InputToggle from './Advanced/InputToggle';
import ArrayLoop from './Advanced/ArrayLoop';
import Performance from './Advanced/Performance';
import RefHook from './Advanced/RefHook';
import CompoundPattern from './Pattern/CompoundPattern';
import Debug from './Pattern/Debug';
import CustomHook from './Advanced/CustomHook';
import CustomDebounce from './Advanced/CustomDebounce';
import CustomForm from './Advanced/CustomForm';
import IntersectionObserverComponent from './Advanced/IntersectionObserver';
import ClassComponent from './Advanced/ClassComponent';
import Prac from './Advanced/Prac';
import List from './CRUD/List';
import FetchApi from './CRUD/FetchApi';
import TodoApp from './CRUD/Todos';
import ReducerHook from './Advanced/ReducerHook';
import Copy from './CustomHooks/Copy';
import Toggle from './CustomHooks/Toggle';
import Selection from './CustomHooks/Selection';
import ClickOutside from './CustomHooks/ClickOutside';
import TwentyTwo from './Advanced/TwentyTwo';
import TwentyThree from './Advanced/TwentyThree';
import Prac2 from './Advanced/Prac2';
import Todo from './Advanced/Todo';
import HOF from './Advanced/HOF/HOF';
import Prac3 from './Advanced/Prac3';

function App() {
  const a = 2;
  const b = 3;
  return (
    <div className="App">
      {/* <BookingApp/> */}
      {/* <ProviderPattern/> */}
      {/* <ContainerView/> */}
      {/* <RenderProp/> */}
      {/* <Home/> */}
      {/* <InputToggle/> */}
      {/* <ArrayLoop/> */}
      {/* <CompoundPattern/> */}
      {/* <Performance/> */}
      {/* <RefHook/> */}
      {/* <CustomHook/> */}
      {/* <Debug/> */}
      {/* <CustomDebounce/> */}
      {/* <CustomForm/> */}
      {/* <IntersectionObserverComponent /> */}
      {/* <ClassComponent/> */}
      {/* <Prac/> */}
      {/* <List/> */}
      {/* <FetchApi/> */}
      {/* <TodoApp/> */}
      {/* <ReducerHook/> */}
      {/* <Copy/> */}
      {/* <Toggle/> */}
      {/* <Selection/> */}
      {/* <ClickOutside/> */}
      {/* <TwentyTwo/> */}
      {/* <TwentyThree/> */}
      {/* <Prac2/> */}
      {/* <Todo/> */}
      {/* <HOF/> */}
      <Prac3/>
    </div>
  );
}

export default App;
