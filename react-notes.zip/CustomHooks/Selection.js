import React, { useEffect, useRef, useState } from 'react'

const useSelectionText = (ref) => {
    const [data,setData] = useState({showTools : false});

    const onMouseUp = () => {
        //get window selection
        const selection = window.getSelection();
      
        //get parent node
        const startNode = selection.getRangeAt(0).startContainer.parentNode;

        //get the end node 
        const endNode = selection.getRangeAt(0).endContainer.parentNode;

        console.log(selection,startNode,endNode) 
        //if the current element is not part of the selection node
        //do not show tools

        if(!startNode.isSameNode(ref.current) ||
          !startNode.isSameNode(endNode)){
            setData({
                showTools: false,
            });
            return;
        }
        //get co-ordinates of selection
        const {x,y,width} = selection.getRangeAt(0).getBoundingClientRect();

        //if not much is selected //do not show tools
        if(!width){
            setData({
                showTools: false
            });
            return
        }

        //if text is selected
        //update the selection
        //and the co-ordinates

        //the y position is adjusted to show bar 
        console.log(selection.toString(),'string')
        if(selection.toString()){
            setData({
                x: x,
                y: y + window.scrollY - 25,
                showTools:true,
                selectedText : selection.toString(),
                width
            })
            const parentElement = selection.anchorNode.parentElement;
            const fontSize = window.getComputedStyle(parentElement).getPropertyValue('font-size');
            // .getPropertyValue('font-size');


                // Create a new range for the selected text
                const range = selection.getRangeAt(0);
                console.log(range,'range')
                const boldSpan = document.createElement('span');
                boldSpan.style.fontWeight = 'bold';
                boldSpan.style.fontSize = `calc(${fontSize} + 2px)`;
                // boldSpan.style.fontSize = 
                range.surroundContents(boldSpan);

            // const range = selection.getRangeAt(0);
            // const wordNode = range.startContainer.splitText(range.startOffset);
            // const boldSpan = document.createElement('span');
            // boldSpan.style.fontWeight = 'bold';
            // boldSpan.appendChild(wordNode.cloneNode(true));
            // range.deleteContents();
            // range.insertNode(boldSpan);
        }

        // if (selection.toString().toLowerCase() === 'harry') {
            // Create a new range for the selected word
    
        //   }

 
    }

    useEffect(()=>{
        //add event
        document.addEventListener('mouseup',onMouseUp);

        //remove the listener
        return () => {
            document.removeEventListener('mouseup',onMouseUp)
        }
    },[]);


    return data;
}


const Selection = () => {
 const ref = useRef();
 const data = useSelectionText(ref);
console.log(data)
  return (
    <div 
    style={{
        display: "flex",
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh'

    }}>
        {/* {data.showTools && (
            <span
            
            style={{
                position: "absolute",
                left: `${data.x + data.width / 4}px`,
                top: `${data.y}px`,
                width: data.width / 2,
                display: "inline-block",
                height: "20px",
                textAlign: "center"
            }}
        >
            <span>Icon 1</span>
            <span>Icon 2</span>
        </span>
        )} */}

        <div  ref= {ref}>
            my name is harry

        </div>
    </div>
  )
}

export default Selection