import React, { useEffect, useState } from 'react'

const useResponsive = () => {

    const [state,setState] = useState({
        isMobile: false,
        isTablet: false,
        isDesktop: false
    })


    useEffect(()=>{
        onResizeHandler()
        Setup();

        return () => {
            Cleanup();
        }

    },[])


        const onResizeHandler = () => {

            const isMobile = window.innerWidth <= 768;
            const isTablet = window.innerWidth >= 768 && window.innerWidth <=990;
            const isDesktop = window.innerWidth > 990;

            setState({isMobile,isTablet,isDesktop});
        }


        const Setup = () => {
            window.addEventListener('resize',onResizeHandler,false)
        }

        const Cleanup  = () => {
            window.removeEventListener('resize',onResizeHandler,false)
        }

        return state

}


const Responsive = () => {
    const {isMobile,isTablet,isDesktop} = useResponsive()
  return (
    <div>Responsive</div>
  )
}

export default Responsive