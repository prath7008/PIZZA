

import React, { useState } from 'react'

const useCopy = () => {
  const [copiedTxt,setCopiedText] = useState();

  const copy = async(text) => {
    if(!navigator?.clipboard){
      console.warn('Clipboard Not Supported');
      return false
    }


    //try to save it in clipboard 

    try{
      await navigator.clipboard.writeText(text);
      setCopiedText(text)
    }catch(error){
      console.error(`Failed copying the ${text}`,error)
      setCopiedText(null);
    }
  };

  return [copiedTxt,copy]
}


const Copy = () => {
  const [copiedTxt,copy] = useCopy();
  return (
    <>
      <button onClick = {()=> copy('Hello World')}>"copiedTxt" : {copiedTxt}</button>
    </>
  )
}

export default Copy