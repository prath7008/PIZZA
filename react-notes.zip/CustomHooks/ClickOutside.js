import { useEffect, useRef } from "react";

function useOnClickedOutside(ref,callback){

    useEffect(()=>{
        const listener = (event) => {

            if(!ref.current || ref.current.contains(event.target)){
                return
            }

            callback(event)
        };

        document.addEventListener('mousedown',listener);
        document.addEventListener('touchstart',listener);

        return () => {
            document.removeEventListener('mousedown',listener);
            document.removeEventListener('touchstart',listener);
        }
        
    },[ref,callback])}

const ClickOutside = () => {
    const ref = useRef();
    useOnClickedOutside(ref,()=>{
        console.log("Clicked!")
    });

    return(
        <div>
            <p>Outside Click me!</p>
            <p ref={ref}>Click me !</p>
        </div>
    )
}

export default ClickOutside