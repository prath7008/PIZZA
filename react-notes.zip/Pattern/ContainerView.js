import React, { useEffect, useState } from 'react'

const ContainerView = () => {
    const [userdata,setUserData] = useState(null);
    const [loading,setLoading] = useState(true);
    const [error,setError] = useState(null)

    async  function fetchData (){
        try{
            let result = await fetch('https://jsonplaceholder.typicode.com/posts/1');
            if(!result.ok) throw new Error(error)
            let resultJson = await result.json();
            setUserData(resultJson)
            setLoading(false)
        }
        catch(error){
            setError(error);
            setLoading(false)
        }
    }  

    useEffect(()=>{
        fetchData()
    },[])


    return (
    <>
        <UserData userdata={userdata} loading={loading} error={error}/>     
    </>
    )
}


const UserData = ({userdata,loading,error}) => {
    console.log(userdata,loading,error)
    if(loading) return <p>Loading..</p>
    if(error) return <p>Error</p>
    // if(!userdata.length) return null;

    return(
        <>
            <p>{userdata.title}</p>
            <p>{userdata.body}</p>
        </>
    )
}

export default ContainerView