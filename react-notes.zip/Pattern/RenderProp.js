import React, { useEffect, useState } from 'react'




const RenderProp = () => {
    return (
        <div>RenderProp

            <UserDetails
                fetchData={async () => await fetch('https://jsonplaceholder.typicode.com/posts/1')
                }
                render={(data) => {
                    return <div>
                        <p>User Info:</p>
                        <p>{data.title}</p>
                        <p>{data.body}</p>
                    </div>
                }}
            >

            </UserDetails>
        </div>
    )

}


const UserDetails = ({ fetchData, render }) => {
    const [userdetails, setUserDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null)


    async function fetchDetails() {
        try {
            let response = await fetchData();
            if (!response.ok) throw new Error(response.statusText);

            let responseJSON = await response.json();

            console.log(responseJSON, 'response2')

            setUserDetails(responseJSON);
            setLoading(false);

        } catch (error) {
            setError(error)
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchDetails(fetchData)
    }, [])

    return (
        <div>
            {loading && <p>Loading..</p>}
            {error && <p>Error..</p>}
            {userdetails && render(userdetails)}
        </div>
    )
}

export default RenderProp


