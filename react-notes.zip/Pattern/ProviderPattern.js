import React, { createContext, useContext, useState } from 'react';




const ProviderPattern = () => {
const CounterContext = createContext(null);

    const CounterProvider = ({children}) => {
        const [counter,setCounter] = useState(0);
        const increament = ()=> setCounter(counter=>counter + 1);
        const decreament = ()=> setCounter(counter=>counter - 1);

        return(
            <CounterContext.Provider value={{counter,increament,decreament}}>
                {children}
            </CounterContext.Provider>
        )
    }

    const useCounter = () => {
        const context = useContext(CounterContext);
        if(!context) throw new Error("Error");
        return context
    }


    const CounterDisplay = ()=>{
        const {counter} = useCounter()
        return(
            <>
                <p>{counter}</p>
            </>
        )
    }

    const CounterOperate = () => {
        const {increament,decreament} = useCounter();
        return(
            <>
                <button onClick={()=>increament()}>Increament</button>
                <button onClick={()=>decreament()}>Decreament</button>
            </>
        )
    }

  return (
    <CounterProvider>
        <CounterDisplay/>
        <CounterOperate/>
    </CounterProvider>
  )
}

export default ProviderPattern