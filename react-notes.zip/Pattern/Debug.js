import React, { useState } from 'react'

const Debug = () => {
  const [details,setDetails] = useState({
    isCitizen: false,
    isAge: false
  })
  const {isCitizen,isAge} = details;

  const onChange = (e) =>{
    setDetails({ 
      ...details,
      [e.target.name] : e.target.checked})
  }

  const onSelect = (e) =>  {
    if(e.target.checked){
      setDetails({ 
        ["isCitizen"] : true,
        ["isAge"] : true
      })
    }else{
      setDetails({ 
        ["isCitizen"] : false,
        ["isAge"] : false
      })
    }
  }

  return (
    <>
      <h1>Citizen of India {isCitizen ?  "YES" : "NO" }</h1>
      <h2>Age above 18 {isAge ? "YES" : "No"}</h2>

      <label>
        Citizen of India
        <input
        name="isCitizen"
        checked={details.isCitizen}
        type='checkbox'
        onChange={onChange}/>
      </label>

      <label>
        Age above 18
        <input
        checked={details.isAge}
        name="isAge"
        type='checkbox'
        onChange={onChange}/>
      </label>

      <label>
        SELECT BOTH
        <input
        name="all"
        type='checkbox'
        onChange={onSelect}/>
      </label>
    </>
  )
}


export default Debug