

import React, { useState } from 'react'

const Tabs = ({children}) =>{
    const [activeTab,setActiveTab] = useState(1);
    
    const handleTabClick = (index) => {
        setActiveTab(index)
    }

    const renderTabs = React.Children.map(children, (child, index) =>
    React.cloneElement(child, {
      isActive: index === activeTab,
      onClick: () => handleTabClick(index),
    })
  );

    const activeTabContent = React.Children.toArray(children)[activeTab];
    console.log(renderTabs)
    return(
        <div>
            <div style={{display: 'flex', marginBottom: '10px'}}>{
                React.Children.map(children, (child, index) => {
                React.cloneElement(child, {
                  isActive: index === activeTab,
                  onClick: () => handleTabClick(index),
                })
            })
            }</div>
            <div>{activeTabContent && activeTabContent.props.children}</div>
        </div>
    )
}

const Tab = ({isActive,onClick,label}) =>{
    <div
    onClick={onClick}
    style={{
        padding: '10px',
        margin: '5px',
        cursor: 'pointer',
        backgroundColor: isActive ? 'lightblue' : 'lightgrey'
    }}
    >
       <div> {label}</div>
    </div>
}

const CompoundPattern = () => {
  return (
    <Tabs>
        <Tab label="Tab 1">Content for Tab 1</Tab>
        <Tab label="Tab 2">Content for Tab 2</Tab>
        <Tab label="Tab 3">Content for Tab 3</Tab>
    </Tabs>
  )
}

export default CompoundPattern