import React, { useEffect, useState } from 'react'

const Form = ({visibility}) =>{

    const [bookingDetail,setBookingDetail] = useState({});


    const handleSearch = (e) =>{
        console.log("HI");
     
    }

    const handleChange = (e) =>{
        setBookingDetail({
            ...bookingDetail,
            adults: e.target.value
        })
        // console.log(bookingDetail["adults"])
    }
    return(
        <div className='form'>
            <div className='row'>
                    <label>Depart From</label>
                    <select onChange={handleChange} >
                        <option>Delhi</option>
                        <option>Mumbai</option>
                        <option>Bangalore</option>
                    </select>
            </div>
            <div className='row'>
                <label>Going to</label>
                <select onChange={handleChange} >
                        <option>Delhi</option>
                        <option>Mumbai</option>
                        <option>Bangalore</option>
                    </select>
            </div>
            <div className='row'>
                <label>Depart Date</label>
                <input type="date"></   input>
            </div>
            <div className='row'>
                <label>Adult</label> 
                <input type="number"/>   
            </div>
            <div className='row'>
                <button onClick={handleSearch}>Search Flights</button>     
            </div>
        </div>
    )
}


const Search = () => {
    const  [visibility,setVisibilty] = useState(false);
    useEffect(()=>{
        setInterval(()=>{
            setVisibilty(!visibility)
        },1000)
    })
  return (
    <>
    <h2>Book your filghts</h2>
    <div>
        <Form visibility={visibility}/>
    </div>
  
    </>)
}

export default Search


