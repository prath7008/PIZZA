import React, { useContext } from 'react'
import UserContext from './UserContext';

const Profile = () => {
    const {userdetails} = useContext(UserContext);
  return (
    <div>Profile
        <p>{userdetails?.user}</p>
    </div>
  )
}

export default Profile