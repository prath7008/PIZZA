import React from 'react'
import Login from './Login'
import Profile from './Profile'
import UserContextProvider from './UserContextProvider'

const Home = () => {
  return (
    <UserContextProvider>
        <Login/>
        <Profile/>
    </UserContextProvider>
  )
}

export default Home