import React, { useContext, useState } from 'react'
import UserContext from './UserContext';

const Login = () => {
  const [user,setUser] = useState('') ;
  const [age,setAge] = useState('');
//   const [formData,setFormData] = useState('')

  const {setUserDetails} = useContext(UserContext);

  const handleSubmit = (e) => {
    e.preventDefault();
    setUserDetails({user,age});
  }
//   console.log(formData)
  return (
    <div>
        <form onSubmit={handleSubmit}>
            <div>
                <label>Username</label> 
                <input type="text" placeholder='Enter UserName Here' value={user} onChange={(e) => setUser(e.target.value)}/>   
            </div>
            <div>
                <label>Age</label>
                <input type="text" placeholder='Enter Age Here' value={age} onChange={(e) => setAge(e.target.value)}/>
            </div>    
            <button>Submit</button>
        </form>        
    </div>
  )
}

export default Login