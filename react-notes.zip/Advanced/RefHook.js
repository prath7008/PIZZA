import React, { forwardRef, useRef } from 'react'

const RefHook = () => {
    const inputRef = useRef(null);
    const handleClick = () => {
        inputRef.current.focus();
    }
  return (
    <>

        <InputText inputRef={inputRef}/>
        {/* <InputTextTwo ref={inputRef}/> */}
        <button onClick={handleClick}>Focus</button>
    </>

  )
}

const InputText = ({inputRef}) => {
    return(
        <>
            <input ref={inputRef} placeholder='Enter Text Here' type='text'/>
        </>
    )
}

const InputTextTwo = forwardRef((props,ref) => {
   
    return(
        <>
            <input ref={ref} placeholder='Enter Text Here' type='text'/>
        </>
    )

})

export default RefHook