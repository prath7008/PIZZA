

import React, { useState } from 'react'

const todos = [
    {
        id:1,
        text: "First"
    },{
        id:2,
        text: "Second"
    },{
        id:3,
        text: "Third"
    }
]

const ArrayLoop = () => {
    const [counter,setCounter] = useState(0);

  return (
   <>
        <button onClick={()=>setCounter(counter=> counter + 1)}>Update</button>
        <p>{counter}</p>
        <ul>
            {todos.map((todo) => {
                return <ItemListMemo key={todo.id} value={todo.text}/>
            })}
        </ul>
   </>
  )
}

const Item = ({value}) => {
    console.log("render")
    return(
        <>
                <li>{value}</li>
        </>
    )
}


const ItemListMemo = React.memo(Item)


export default ArrayLoop