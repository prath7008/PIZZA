import React, { useState } from 'react'
import './StarWidget.css'
const StarWidget = () => {
    const [rating,setRating] = useState(0);
    const [hover,setHover] = useState(0)
  return (
    <>
        <h1>Star Widget Rating</h1>
        {
            [1,2,3,4,5].map((num)=>(
                <button
                    key={num}
                    onClick={()=> setRating(num)}
                    onMouseOver={()=> setHover(num)}
                    onMouseLeave={()=>setHover(rating)}
                >
                    <span
                        className={
                            `star ${num <= ((rating && hover) || hover) ? 'on' : 'off'}`
                        }
                    >&#9733;</span>
                </button>

            ))

        }
    </>
  )
}

export default StarWidget