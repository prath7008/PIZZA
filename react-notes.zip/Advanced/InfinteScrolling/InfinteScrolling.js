import { entries } from "lodash";
import { useCallback, useEffect, useRef, useState } from "react"



    const InfiniteScrolling = () =>  {

        const [images,setImages] = useState([]);
        const loaderRef = useRef();
        const [page,setPage] = useState(2);
        const [loading,setLoading] = useState(false);


        const fetchImages = async(index) => {
            try{
                const url = `https://jsonplaceholder.typicode.com/photos?_page=${index}`
                const result = await fetch(url);
                const data = await result.json();
                return data
            }
            catch(err){
                console.log('error'+ err)
            }   
        }

        const fetchFirstPage = async () => {
            const data = await fetchImages(1);
            setImages(data)
            // console.log(data)
        }

        const getData = useCallback(async()=>{
            if(loading) return 
            
            setLoading(true)

            const data = await fetchImages(page);
            setImages((prevImages) => [...prevImages,...data])
            
            setTimeout(()=>{
                setLoading(false)
            },3000)
         
            setPage((prevPage) => prevPage + 1);


        },[page,loading])

        useEffect(()=>{
            const observer = new IntersectionObserver((entries) =>  {
                const  target = entries[0];
                if(target.isIntersecting){
                    //call next Page Data
                    getData()
                }
            })

            if(loaderRef.current) {
                observer.observe(loaderRef.current)
            }

            return () =>{
                if(loaderRef.current){
                    observer.unobserve(loaderRef.current)
                }            
            }
        },[getData])

        useEffect(()=>{
            fetchFirstPage()
        },[])


        return(
            <div className="infiniteWrapper">
                <h1>Infinte Scrolling</h1>
                {images?.map((image,index)=>(
                        <img
                            key={index}
                            alt={image.title}
                            src={image?.thumbnailUrl}
                        />

                ))}
                <div ref={loaderRef}> </div>
                {
                    loading && <h2>Loading..</h2>
                }
            </div>
        )
    }

    export default InfiniteScrolling