import { useEffect, useState } from 'react'
import  productsData from './cart.json'
import './Cart.css';

const Cart = () => {
    const [products,setProducts] = useState(productsData);
    const [cart,setCart] = useState([]);
    const [total,setTotal] = useState(0);

    const addCart = (selectedproduct) => {
        console.log(selectedproduct,cart.length,'selectedproduct')
        if(cart.length){
            setCart(cart.map(prod => prod.id === selectedproduct.id ? selectedproduct : prod ))
        }
        else{
            setCart([selectedproduct])
        }
    }

    const deleteProduct = (selectedproduct) => {
        setProducts(products.filter(prod => prod.id != selectedproduct.id))
    }

    const decreaseQuantity = (product) => {

            let newProdCount = products.map(prod => 
                prod.id === product.id 
            ? {...prod, count: (prod.count || 1) > 1 ? prod.count - 1 : 1} 
            : prod )
            setProducts(newProdCount)
    }

    const increaseQuantity = (product) => {
      
        let newProdCount = products.map(prod => 
            prod.id === product.id 
        ? {...prod, count: (prod.count || 1) + 1} 
        : prod )

        setProducts(newProdCount)
    }

    const calculateTotalPrice = () => {
        console.log(cart,'cart')
    }
    return(
        <>
            {
                products.length > 0 &&  (
                    <div className='productsWrp'>
                        {
                            products.map(product=>(
                                <div className='product' key={product.id}>
                                    <img src = {product.image}alt=''/>
                                    <p>Name {product.name}</p>
                                    <p>Price {product.price}</p>
                                    <p>Count {(product.count || 1)}</p>
                                    <button onClick={()=>addCart(product)}>Add Cart</button>
                                    <button onClick={()=>deleteProduct(product)}>Delete Cart</button>
                                    <button onClick={()=>decreaseQuantity(product)}>-</button>
                                    <button onClick={()=> increaseQuantity(product)}>+</button>
                                </div>
                                
                            ))
                        }
                    </div>
                )
            }

            {
                cart.length > 0 && (
                    <div className='cartWrp'>
                        {
                            cart.map(product => (
                                <div className='cart' key={product.id}>
                                    <p>Product {product.name}</p>
                                    <p>Price {product.price}</p>
                                    <p>Count {product.count}</p>
                                </div>
                            ))
                        }
                        <p>Total Amount:- {calculateTotalPrice()}</p>
                    </div>
                )
            }

    
        </>
    )
}

export default Cart