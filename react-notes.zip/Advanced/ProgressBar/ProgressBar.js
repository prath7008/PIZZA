import React from 'react';
import './Progress.css'
import {useState,useEffect} from "react";
import { MAX, MIN } from './constants';

const ProgressBar = () => {
  const [value,setValue] = useState(0)
  const [success,setSuccess] = useState(false)
  
  useEffect(()=>{
    setInterval(()=>{
        setValue((val) => val + 1);
    },100)
  },[])

  return(
    <>
      <div className='app'>
        <span>ProgressBar</span>
        <ProgressBarFunc value={value} onComplete={()=>setSuccess(true)}/>
        <span>{success ? "Complete" : "Loading..."}</span>
      </div>
    </>
  )
}

const ProgressBarFunc = ({value=0,onComplete =() => {}}) => {
 
  const [percent,setPercent] = useState(value)

  useEffect(()=>{
    // setInterval(()=>{
      setPercent(Math.min(MAX,Math.max(value,MIN)));

      if(value >= MAX){
        onComplete()
      }
    // },100)
  },[value])

  return (
    <div className='progress'>
        <span
          styles={{color : percent > 49 ? "white" : "black"}}
        >{percent.toFixed()}%</span>
        <div 
          style={{width : `${percent}%`}}
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={percent.toFixed()}
        >  
        </div>
    </div> 
  )
}

export default ProgressBar