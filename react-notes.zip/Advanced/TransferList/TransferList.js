import React, { useState } from 'react';
import './TransferList.css';
import {data} from  './data'

const TransferList = () => {
    const [leftItems,setLeftItems] = useState(data);
    const [rightItems,setRightItems] = useState([]);

    const checkedList = (list,id,checked)=>{
        return list.map((item) => {
            if(id == item.id){
                return{
                    ...item,
                    checked: !checked
                }
            }
            return item
        })
    }
    const handleClick = (id,checked,direction) => {
        if(direction === 'left'){
            let copyList = [...leftItems];
            copyList = checkedList(copyList,id,checked);
            setLeftItems(copyList)
        }else{
            let copyList = [...rightItems];
            copyList = checkedList(copyList,id,checked);
            setRightItems(copyList)
        }
    }

    const resetItems = (list) => {
        return list.map((item) => {
          return{  
            ...item,
            checked: false
          }
    }   )
    }

    const handleTranserButton = (direction) => {
        if(direction === 'LEFT_TO_RIGHT'){
            if(leftItems.length){
                const copyList = [...leftItems];
                const checkedList = copyList.filter((item) => item.checked);
                const unCheckedList = copyList.filter((item) => !item.checked)

                setRightItems(resetItems([...rightItems,...checkedList]))
                setLeftItems(unCheckedList)
            }
        }else{
            const copyList = [...rightItems];
            const checkedList = copyList.filter((item) => item.checked);
            const unCheckedList = copyList.filter((item) => !item.checked)

            setLeftItems(resetItems([...leftItems,...checkedList]))
            setRightItems(unCheckedList)
        }
    }

  return (
    <div className='TransferList'>
        <h1>Transfer List</h1>
        <div className='container'>
            <div className='box'>
                {
                    leftItems.map(({title,id,checked})=>(
                        <div 
                        className={`item ${checked && 'checked'}`}
                        onClick={()=>handleClick(id,checked,'left')}
                        id={id}
                        key={id}
                        >
                            {title}
                        
                        </div>
                    ))
                }
            </div>
            <div className='actions'>
                <button onClick={()=>handleTranserButton('LEFT_TO_RIGHT')}>Left</button>
                <button onClick={()=>handleTranserButton('RIGHT_TO_LEFT')}>Right</button>
            </div>
            <div className='box'>
            {
                    rightItems.map(({title,id,checked})=>(
                        <div 
                        className={`item ${checked && 'checked'}`}
                        onClick={()=>handleClick(id,checked,'right')}
                        id={id}
                        key={id}
                        >
                            {title } 
                        </div>
                    ))
                }
            </div>
        </div>
    </div>
  )
}

export default TransferList