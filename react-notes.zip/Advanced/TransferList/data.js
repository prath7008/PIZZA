
export const data = [
    {title:'FIRST',id:0,checked:false},
    {title:'SECOND',id:1,checked:false},
    {title:'THIRD',id:2,checked:false},
    {title:'FOURTH',id:3,checked:false},
]