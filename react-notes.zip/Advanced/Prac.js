import React, { useCallback, useEffect, useState } from 'react';

function Prac() {

    
    return (
        <>  
            <UserDetails 
            fetchData={async()=> await fetch('https://jsonplaceholder.typicode.com/posts/1')}
            render={(data)=>(
                <div>
                    <p>{data.title}</p>
                    <p>{data.body}</p>
                </div>
            )}
            />
        </>
    );
}


const UserDetails = ({fetchData,render})=>{

    const [userDetails,setUserDetails] = useState(null);
    const [loading,setLoading] = useState(true);
    const [error,setError] = useState(false);

    async function fetchUserDetails(){
    
        try{
            const response = await fetchData();

            if(!response.ok) throw new Error(response.statusText);
            const responseJSON = await response.json()
            setUserDetails(responseJSON)
            setLoading(false)
        }
        catch(err){
            setError(err);
            setLoading(false)
        }
        
    }

    useEffect(()=>{
        fetchUserDetails()
    },[])

    return(
        <>
                {loading  && <p>Loading</p>}
                {error  && <p>Error</p>}
                {userDetails && render(userDetails)}
        </>
    )
}


export default Prac;

