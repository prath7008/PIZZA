
import './Task.css';
import React, { useMemo, useRef, useState } from 'react'

const Tasks = () => {
    const [tasks,setTasks] = useState(
        {
            todo: [
                {
                    id: 1111,
                    title: 'Task 1',
                    category: "todo"
                },
                {
                    id: 21,
                    title: 'Task 2',
                    category: "todo"
                }
      
      
            ],
            progress : [
               {
                id: 11,
                title: 'Task 2',
                category: 'progress'
               }

            ],
            completed: [
                {
                    id: 1,
                    title: 'Task 3',
                    category: 'completed'
                   }
            ]
        }
    );
    const [editingTask,setEditingTask] = useState();

    const categories = useMemo(() => {
        return Object.keys(tasks)
    },[tasks])

    const editTaskHandler = (payload) => {
        const oldTask = editingTask;
        //create new task object
        const newTask = payload;
        //remove it from the list
        const oldList = [...tasks[oldTask.category]].filter(task => task.id != oldTask.id);
        //add it to new list
        const newList = [...tasks[newTask.category]];
        //if the category is same, we ill update details
        newList.push(newTask)
        //if not then will remove task from one list and add on another

        setTasks(prev => ({
            ...prev,
            [newTask.category]: newList,
            [oldTask.category] : oldList
        }))



    }

    const addNewTaskHandler = (payload) => {
        const tempTaskList = [...tasks[payload.category]];
        tempTaskList.push(payload);

        setTasks(prev=> ({
            ...prev,
            [payload.category] : tempTaskList
        }))
    }
    return (
        <div className='categoryContainer'> 
        {editingTask?.title || "-"} 
            <TaskForm 
            mode={editingTask ? 'edit' : 'add'} 
            task={editingTask} 
            addNewTaskHandler ={addNewTaskHandler} 
            editTaskHandler={editTaskHandler}/>
            <div className='categoryWrp'>
                {categories.map((category,index) => (
                <TaskList key={index} name={category}> 
                    {
                        tasks[category].map(task=> (
                            <div key={task.id}>
                                <TaskCard task={task} setAsEditing={setEditingTask}/>
                            </div>
                        ))
                    }
                </TaskList>)
                )}
           </div>
        </div>
    )
}

    //Components 

const TaskForm = ({addNewTaskHandler,mode='add',task,editTaskHandler}) => {

    const titleRef = useRef();
    const optionRef = useRef();

    const resetForm = () => {
        titleRef.current.value ='';
        optionRef.current.value ='';
    }

    const options = [
        {label : "Todo",value : "todo"},
        {label : "Progress",value : "progress"},
        {label : "Completed",value : "completed"}
    ]

    const handleSubmit = (event) => {
        event.preventDefault()
        const payload = {
            id:  mode === "add" ?  Math.random() : task.id,
            title : titleRef.current.value,
            category: optionRef.current.value
        }
        console.log('handle submit',{
            title : titleRef.current.value,
            category: optionRef.current.value
        })
        if(mode === 'add'){
            addNewTaskHandler(payload);
        }
        else{
            editTaskHandler(payload)
        }
        resetForm()
   
    }

    return(
        <div>
                <h5>Create new task</h5>
                <form onSubmit ={handleSubmit}>
                    <input type='text' placeholder='Task title' ref={titleRef} defaultValue={task?.title || ''}/>
                    <select defaultValue={task?.category || ''} ref={optionRef}>
                        {options.map(option => (
                            <option key={option.value} 
                            value={option.value} 
                            selected={task?.option === option.value}
                            >{option.label}</option>
                        ))}
                    </select>
                    <button type='submit'> {mode === "add" ? "Add task" : "Edit Task" }  </button>
                </form>
        </div>
    )
}

const TaskList = ({name,children}) => {
    return(
            <div className='category'> 
                <div id='task-list-header'>
                    <p>  {name.toUpperCase()} </p>
                </div>
                {children}
                <div>
                    <button> Add Cards</button>
                </div>
            </div>

    )
}

const TaskCard = ({task,setAsEditing}) => {
    return(
                <div 
                className='category-card'> 
                    <p>{task.title}</p>
                    <button onClick={()=> setAsEditing(task)}>Edit</button>
            </div>

    )
}


export default Tasks