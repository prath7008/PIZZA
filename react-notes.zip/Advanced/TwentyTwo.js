import React, { useCallback, useMemo, useReducer, useState } from 'react'

const TwentyTwo = () => {
    
    const [counter,setCounter] = useState(0);
    const todos = [
        {
            id:1,
            text: 'TODO1'
        },
        {
            id:2,
            text: 'TODO2'
        },
        {
            id:3,
            text: 'TODO3'
        }
    ]

    const obj = useMemo(()=>{
        return {name:'prath'}
    })

    const onClick = useCallback(()=>{
        setCounter(counter=>counter+1)
    },[])

    return (
        <>
            <div>TwentyTwo</div>
            <p>{counter}</p>

            {todos.map(todo=>{
                return <ItemMemo key = {todo.id} value ={todo.text} onClick={onClick} obj={obj}/>
            })}
            
        </>
    )
}

const Item = ({value,onClick,obj}) => {
    return(
        <>
            <button onClick={onClick}>increament</button>
            <p>{value}</p>
            <p>{obj.name}</p>
        </>
    )
}


const ItemMemo = React.memo(Item)
export default TwentyTwo