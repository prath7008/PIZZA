import React, { useState } from 'react'

const CustomTabs = () => {
    const [activeIndex,setActiveIndex] = useState(1);

    const [data,setData]= useState([
        {
           id:1,
           title: 'TAB 1',
           content: 'CONTENT TAB 1'

        },{
            id: 2,
            title: 'TAB 2',
            content: 'CONTENT TAB 2'
        },
        {
            id: 3,
            title: 'TAB 3',
            content: 'CONTENT TAB 3'
        }
    ])

    const handleClick = (event) => {
        const idx = event.target.getAttribute('data-id');
        console.log(idx,'id')
        setActiveIndex(+idx)        
    }
  return (  
    <>
        <h1>Custom Tabs</h1>
        {
            // data.map((ele,index) => (
                <div>
                    <div className='tabs'>
                        <Tab title='TAB 1' id={1} handleClick={handleClick} active={1 === activeIndex} />
                        <Tab title='TAB 2' id={2} handleClick={handleClick} active={2 === activeIndex} />
                        <Tab title='TAB 3' id={3} handleClick={handleClick} active={3 === activeIndex} />
                    </div>
                    <div className='content-wrp'>
                        <Content content='CONTENT TAB 1' active={1 === activeIndex}/>
                        <Content content='CONTENT TAB 2' active={2 === activeIndex}/>
                        <Content content='CONTENT TAB 3' active={3 === activeIndex}/>
                    </div>
                </div>
            // ))
        }
       
    </>
  )
}


const Tab  = ({id,title,handleClick,active}) => {
    return <button data-id={id} style={{backgroundColor: active ? '#000': ''}} onClick={handleClick}>{title}</button>
}

const Content = ({content,active}) => {
    return(
        <>
            {active ? content : ''}
        </>
    )
}

export default CustomTabs