

import React, { memo, useEffect, useRef, useState } from 'react';

const todos = [
    {
        id:1,
        text: 'ONE'
    },
    {
        id:2,
        text: 'TWO'
    },
    {
        id: 3,
        text: 'THREE'
    }
]

const Prac2 = () => {
    
    const [counter,setCounter] = useState(0);
    const [datas,setData]  = useState([]);
    const ref = useRef(counter);

    const handleCounter = () => {
        console.log(counter,'counter')
        setCounter(counter=> counter+1)
       }

    useEffect(()=>{
        async function ApiCall(){
            let response = await fetch('https://jsonplaceholder.typicode.com/users');
            let responseJSON = await response.json();
            return responseJSON 
        }

      async function main(){
        let results = await ApiCall();
        console.log(results,'results');
        setData(results)
      }

      main()
     

    },[counter])
    

  return (
    <>
        <p>{counter}</p>
        <button onClick={()=>handleCounter()}>Click Here</button>

        {todos.map((todo)=> {
            return <ItemMemo key = {todo.id} value={todo.text}/>
        })}

        {datas.length && datas.map((data)=>{ 
            return <ListMemo key ={data.id} name={data.name} email={data.email} />
        })}
    </>
  )
}

    const Item = ({value})=> {
        console.log('RENDER ITEM ONE')
        return(
            <>
                <p>{value}</p>
            </>
        )
    }

    const ListData = ({name,email}) => {
        console.log('RENDER ITEM TWO')
        return(
            <>  
                <p>{name}</p>
                <p>{email}</p>
            </>
        )
    }

    const ListMemo = memo(ListData)
    const ItemMemo = memo(Item)

export default Prac2