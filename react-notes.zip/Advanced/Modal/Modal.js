import React, { useState } from 'react'
import './Modal.css'


const Modal = () => {
    const [isShow,setIsShow] = useState(false);
    const [isOfferAccepted,setIsOfferAccepted] = useState(false);

    const handleOpenModal = () => {
        setIsShow(true)
    }

    const handleClose = () => {
        setIsShow(false)
    }

    const handleOfferAccepted = () => {
        setIsOfferAccepted(true)
        setIsShow(false)
    }

    return (
        <div>
            <div className='show-offer'>
                {!isOfferAccepted && <button            
                        onClick={handleOpenModal}
                        className='offer-btn'>
                        Show Offer
                    </button> 
                }
                { isOfferAccepted && 
                <div style={{fontSize: 50}}>Offer Accepted</div>}
            </div>

            {isShow && <ModalWrp handleClose={handleClose} handleOfferAccepted={handleOfferAccepted} />}
        </div>
    )
}


const ModalWrp = ({handleClose,handleOfferAccepted}) => {

    const handleOutsideClick = (e) => {
        console.log(e.target.className )
        if(e.target.className === 'modal'){
            handleClose()
        }
    }

    return <div className='modal' onClick={handleOutsideClick}>
        <div className='modal-content'>
            <button 
            onClick={handleClose}
            className='close-btn'>
                X
            </button>
            <div className='content'>
                Click the button below
                to accept our amazing offer
            </div>
            <button 
                onClick={handleOfferAccepted}
                className='accept-btn'>
                    Accept Offer
            </button>
        </div>
    </div>


}

export default Modal