import React, { useState } from 'react'

const InputToggle = () => {

  const [toggle,setToggle]= useState(true);

  return (
    <>
        <div>InputToggle</div>
        <button onClick={()=>setToggle(!toggle)}>Click Here</button>
        {/* {toggle ? <input key="Name" type="text" placeholder='Enter Name Here'/> : <input key="Email" type="text" placeholder='Enter Email Here'/> } */}
        {toggle && <input  type="text" placeholder='Enter Name Here'/> }
        {!toggle &&  <input  type="text" placeholder='Enter Email Here'/> }
    </> 
  )
}

export default InputToggle