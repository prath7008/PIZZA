import React, { useEffect, useState } from 'react'

const useDebounce = (value,delay) => {
    const [debouncedVal, setDebounceFunc] = useState(value);

    useEffect(()=>{
        const handler = setTimeout(()=>{
            setDebounceFunc(value)
        },delay);

        return (()=> clearTimeout(handler))

    },[value])

    return [debouncedVal,setDebounceFunc]
}


const CustomDebounce = () => {
  const [value,setValue] = useState(0);
  const [debounceVal,setDebounceFunc] = useDebounce(value,500);

  return (
   <>
     <p>{debounceVal}</p>
     <button onClick={()=>setValue(value+1)}>Click Here</button>
   </>
  )
}

export default CustomDebounce