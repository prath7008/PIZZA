import React, { useState } from 'react'
import './FormValidation.css'

const FormValidation = () => {

  let [fields,setFields] = useState(
    {
    name: {
        id: 'name',
        type: 'text',
        placeholder:'Enter Name Here',
        value: '',
        error: ''
    },
    email: {
        id: 'email',
        type: 'email',
        placeholder: 'Enter Email Here',
        value: '',
        error: ''
    },
    password: {
        id: 'password',
        type: 'password',
        placeholder: 'Enter Password Here',
        value: '',
        error: ''
    }
  }
) 

const handleInputChange = (event) => {
    const key  = event.target.id;
    const value = event.target.value;

    const copyForm = {...fields};
    copyForm[key].value = value
    setFields(copyForm)
}

const handleSubmit = () => {
    console.log(fields)
}


  return (
    <>
        {
            Object.keys(fields)
            .map(key => {
                let {id,value,placeholder,type, error} = fields[key];

                return <div className='wrapper'>
                            <input
                                key={id} 
                                id={id}
                                type={type}
                                placeholder={placeholder}
                                value={value}
                                onChange={(e) => handleInputChange(e)}
                            />
                        {key.error && <span> Error is {key.error}</span>}   
                    </div>
            })
        }
        <button onClick={handleSubmit}>Submit</button>
    </>
  )
}

export default FormValidation