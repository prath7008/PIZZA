import React, { useEffect, useState } from 'react'
import './ImageCarousel.css'



const ImageCarousel = () => {
    const [images,setImages] = useState([]);
    const [index,setIndex] = useState(0);

    const fetchImages = async() => {
        const url = 'https://www.reddit.com/r/aww/top/.json?t=all'
        const res= await fetch(url);
        const result = await res.json();
        const data = result.data.children;
        console.log(data,'data')
        
        const list = data.filter((item) => 
            item.data.url_overridden_by_dest.includes('.jpg'))
            .map((item) =>item.data.url_overridden_by_dest);

        console.log(list)
        setImages(list)
    }


    useEffect(()=>{
        fetchImages();       
    },[])

    const handleClick = (dir) => {
        console.log('curr index',index)

        const lastIdex = images.length - 1;

        if(dir == 'left'){
            if(index ===0){
                setIndex(lastIdex)
            }else{
                setIndex((prevIndex) => prevIndex - 1)
            }
        }

        if(dir === 'right'){

            if(index === lastIdex){
                setIndex(0)
            }else{
                setIndex((prevIndex) => prevIndex + 1)
            }
         
        }
    }

    useEffect(()=>{
        const idx = setInterval(()=>{
            handleClick('right');
        },10000)

        return () => {
            clearInterval(idx)
        }
    },[index])




  return (
    <>
    {images.length > 0 && (
        <div className='ImageCarousel'>
            <button
            onClick={()=>handleClick('left')}>
                {'<'}
            </button>
            <img src={images[index]} alt='not found'/>
            <button
            onClick={()=>handleClick('right')}
            className='right'>
                {'>'}
            </button>
        </div>
    )}
    </>

  )
}

export default ImageCarousel