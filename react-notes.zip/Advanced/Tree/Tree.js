

import React, { useState } from 'react';
import './Tree.css';
import {files} from './data';

const Tree = () => {

  return (
    <>  
    <div className='tree'> 
        <Folder files={files}/>
    </div>
    </>

  )
}


const Folder = ({files}) => {
    console.log(files,'files')
    const [expand,setExpand] = useState(false);

    return(
        <div>
            <div
                onClick={()=>setExpand(!expand)}
            >
                {files.isFolder ? (
                        <button
                            className={expand ? 'expand': ''}
                        >
                            {">"}
                        </button>
                ) : null
            }
            {files.name}
            </div>
            {
                files.isFolder &&  expand && 
                files.children.map((exp)=>(
                    <div style={{paddingLeft: '20px'}}>
                        <Folder files={exp}/>
                    </div>
                ))
            }
        </div>
    )
}

export default Tree