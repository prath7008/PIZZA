import React from 'react'

const LayoutEffect = () => {
  return (
    <div>LayoutEffect</div>
  )
}

export default LayoutEffect