import React, { useState,useEffect } from 'react'

const DropDown = () => {
    const suggestions = ['Apple', 'Banana', 'Cherry', 'Date', 'Elderberry','Fig', 'Grape', 'Honeydew', 'Indian Fig', 'Jackfruit']
    return(
        <>
                <h1>Auto Suggestion</h1>
                <AutoSuggest suggestions={suggestions}/>
        </>
    )
}


const  useDebounce = (value,delay) => {
    const [debouncedVal,setDebounceValue] = useState(value);

    useEffect(()=>{
        const handler = setTimeout(()=>{
            setDebounceValue(value)
        },delay)

        return ()=> {
            clearTimeout(handler)
        }
    },[value,delay])
    return debouncedVal
}

const AutoSuggest  = ({suggestions}) => {

    const [query,setQuery] = useState('');
    const [filterSuggestion,setFilterSuggetions] = useState([]);
    const [showSuggestion,setShowSuggestion] = useState(false);
    const [activeSuggestionIndex, setActiveSuggestionIndex] = useState(0);

    // const filterInputByText =  useCallback(
    //     _.debounce((query) =>  {
    //             if(query){
    //                 const newSuggestions = suggestions.filter(fruit => fruit.toLowerCase().includes(query.toLowerCase()));
    //                 setFilterSuggetions(newSuggestions)
    //                 setShowSuggestion(true)
    //             }else{
    //                 setFilterSuggetions([])
    //                 setShowSuggestion(false)
    //             }
    //         },300),
    //     [suggestions]
    //     )

    // useEffect(()=>{
    //     filterInputByText(query)
    // },[query])


    const debouncedQuery = useDebounce(query,300);

    useEffect(()=>{
        if (debouncedQuery) {
            const filtered = suggestions.filter(suggestion =>
                suggestion.toLowerCase().includes(debouncedQuery.toLowerCase())
            );
            setFilterSuggetions(filtered);
            setShowSuggestion(true);
        } else {
            setFilterSuggetions([]);
            setShowSuggestion(false);
        }
    },[debouncedQuery])

    const handleInputClick = (event) => {
        setQuery(event.target.value)
    }

    const handleKeyDown = (event) => {
        if (event.key === 'ArrowDown') {
            if (activeSuggestionIndex < filterSuggestion.length - 1) {
                setActiveSuggestionIndex(activeSuggestionIndex + 1);
            }
        } else if (event.key === 'ArrowUp') {
            if (activeSuggestionIndex > 0) {
                setActiveSuggestionIndex(activeSuggestionIndex - 1);
            }
        } else if (event.key === 'Enter') {
            setQuery(filterSuggestion[activeSuggestionIndex]);
            setFilterSuggetions([]);
            setShowSuggestion(false);
        }
    }

    const handleChange = (event) => {
        setQuery(event.target.value)
        setFilterSuggetions([])
        setShowSuggestion(false)
    }   

    return(
        <>
            <input 
                type ='text'
                query={query}
                onChange = {handleInputClick}
                onKeyDown= {handleKeyDown}
                placeholder='Enter Something'
            />
            <ul className='sugesstion-wrapper'>
                {filterSuggestion.length && showSuggestion  ? 
                    filterSuggestion.map((suggestion,index) => (
                            <li 
                            key={index}
                            style={{backgroundColor: index === activeSuggestionIndex ? 'red' : ''}}
                            className={index === activeSuggestionIndex ? 'active' : ''}
                            onClick={(event)=>handleChange(event)}
                            >{suggestion}</li>
                    )      
                ): <li>No Results Found</li>}
            </ul>
        </>
    )
}
export default DropDown