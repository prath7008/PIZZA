import React, { useEffect, useState } from 'react'


const useLocalStorage = () => {

    function set(key,data){
        window.localStorage.setItem(key,data)
    }

    function get(key){
        return window.localStorage.getItem(key)
    }
    function remove(key){
         window.localStorage.removeItem(key)
    }

    return [set,get,remove]
}

const CustomHook = () => {
        const [set,get,remove] = useLocalStorage();
        const [value,setValue] = useState("");

        console.log("render")
        return (
        <>
            <div>CustomHook</div>
            <input type="text" value={value} onChange={(e)=>setValue(e.target.value)} placeholder='Enter Text Here' />
            <button onClick={()=>set("inputText",JSON.stringify(value))}>SET</button>

            <button onClick={()=>setValue(JSON.parse(get("inputText")))}>GET</button>
            <button onClick={()=>remove("inputText")}>REMOVE</button>

        </>
        
    )
}

export default CustomHook