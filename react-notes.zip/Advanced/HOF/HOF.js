

import React, { useEffect, useState } from 'react'
import withFetchDetails from './withDataFetching';

const UserComponent = (data) => {

    return(
        <>
            <p>Details</p>
            <p>Title {data.title}</p>
        </>
    )
}


const HOF = withFetchDetails(UserComponent,'https://jsonplaceholder.typicode.com/todos/1')
export default HOF