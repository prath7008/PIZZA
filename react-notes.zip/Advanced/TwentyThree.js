import React, { createContext, forwardRef, useContext, useEffect, useRef, useState } from 'react'

const UserContext = createContext(null)

const TwentyThree = () => {


  return (
    <>
        <Child1 
            fetchData = {async()=> await fetch('https://jsonplaceholder.typicode.com/posts/1')}
            results={(data)=>{
               return <p>{data.body}</p>
            }}
            loader ={()=> <p>Loading...</p>}
            err = {()=> <p>Error...</p>}
        />
    </>

  )
}

const Child1 = ({fetchData,results,loader,err}) => {

    const [data,setData] = useState(null);
    const [loading,setLoading] = useState(true);
    const [error,setError] = useState(false);

    useEffect(()=>{
       
        const fetchApi = async() => {
            try{
                const response = await fetchData();
                const responseData = await response.json()
                setData(responseData)
                setLoading(false)
            }
            catch(err){
                setError(err);
                setLoading(false)
            }
       
        }

        fetchApi()
        
    },[fetchData])
    console.log(data);



    return(
        <>  
            {loading && loader()}
            {error && err()}
            {data && results(data)}
        </>
    )
}



export default TwentyThree