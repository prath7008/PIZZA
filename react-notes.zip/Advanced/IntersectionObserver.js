import React, { useRef, useEffect } from 'react';

const IntersectionObserverComponent = () => {
  const targetRef = useRef(null);

  useEffect(() => {
    const options = {
      root: null, // use the viewport as the root
      rootMargin: '0px',
      threshold: 0.5, // trigger when 50% of the target is visible
    };

    const callback = (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          // Load or trigger the desired action when the target is visible
          console.log('Target is intersecting!');
        }
      });
    };

    const observer = new IntersectionObserver(callback, options);

    if (targetRef.current) {
      observer.observe(targetRef.current);
    }

    // Clean up the observer when the component unmounts
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={targetRef} style={{ height: '200px', background: 'lightgrey' }}>
      {/* Content to be conditionally loaded */}
      Target Element
    </div>
  );
};

export default IntersectionObserverComponent;
