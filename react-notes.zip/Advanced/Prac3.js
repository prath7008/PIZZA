import React, { Children, createContext, memo, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useReducer, useRef, useState } from 'react'

// import './Prac3.css'
import Tasks from './Board/Task'
import Contact from './ContactBook/Contact'
import Cart from './ShoppingCart/Cart'
// import { fetchProducts, setProducts } from '../../../../Redux/my-app/src/store/productSlice.'
import _ from 'lodash';
// import TransferList from './TransferList/TransferList';
import Tree from './Tree/Tree';
import CustomTabs from './CustomTabs/CustomTabs';
// import DragNDrop from './DragNDrop/DragNDrop';
// import TicTacToe from './TicTacToe/TicTacToe';
// import FormValidation from './FormValidation/FormValidation';
// import StopWatch from './StopWatch/StopWatch';
// import Board2 from './Board2/Board2';
// import InfiniteScrolling from './InfinteScrolling/InfinteScrolling';
// import Otpbox from './OtpBox/Otpbox';
// import Modal from './Modal/Modal';
// import ImageCarousel from './ImageCarousel/ImageCarousel';
// import ShoppingList from './ShoppingList/ShoppingList';
// import StarWidget from './StarWidget/StarWidget';
// import FAQ from './FAQ/FAQ';

const Prac3 = () => {

    // const [listOne,setListOne] = useState([
    //     'LIST 1', 'LIST 2', 'LIST 3'
    //   ]) 
    
    //   const [listTwo,setListTwo] = useState([
    //     'LIST A','LIST B','LIST C'
    //   ])
    //   const [checkedList,setCheckedList] = useState(Array(listOne.length).fill(false));
    
    
    //   const handleSubmit = () => {
    //     const switchPositions = checkedList.map((list,index) => (list === true) ? index : null ).filter(index => index !== null);
    //     console.log(switchPositions,'switchPositions');
    //     const copyListOne =  [...listOne];
    //     // const newListOne = copyListOne.filter((item,index) => !switchPositions.includes(index));
        
    
    //     const copyListTwo = [...listTwo];
    //     // const newListTwo = copyListTwo.filter((item,index) => !switchPositions.includes(index));
    
    //     let newListOne = [...copyListOne];
    //     let newListTwo = [...copyListTwo]
    
    //     switchPositions.forEach(number => {
    //         newListOne.splice(number,1,copyListTwo[number]);
    //         newListTwo.splice(number,1,copyListOne[number])
    //     })
      
    //     console.log(newListOne,newListTwo)
    //     setListOne(newListOne)
    //     setListTwo(newListTwo)
    // }

    // const handleCheckbox = (index) => {
    //     const copyItems = [...checkedList];
    //     copyItems[index] = !copyItems[index];
    //     setCheckedList(copyItems)
    // }

    // const [fields,setFields] = useState([{value:''}]);

    // const handleInputChange = (event,index) => {
    //   let copyFields = [...fields];
    //   copyFields[index].value = event.target.value;
    //   setFields(copyFields)
    // }
  
    // const handleAddField = () => {
    //   const copyFields = [...fields,{value:''}];
    //   setFields(copyFields)
    // }
  
    // const handleRemoveField = (id) => {
    //   let copyField = [...fields];
    //   copyField = copyField.filter((field,index)=> index != id)
    //   setFields(copyField)
    // }
  
    // const handleSubmit = () => {
    //   console.log(fields)
    // }

    
  const [details,setDetails] = useState([
    {
      id:1,
      text: 'one',
      isDone: false
    },
    {
      id: 2,
      text: 'two',
      isDone: false
    },
    {
      id: 3,
      text: 'three',
      isDone: true
    }
  ])

  const handleChange = (id) => {
    let copyDetails = [...details];
    copyDetails = copyDetails.map((ele)=> {
        if(ele.id == id){
          ele.isDone = !ele.isDone
        }

        return ele
    })

    setDetails(copyDetails)
  }


    
    return(
        <>
           {details.length > 0 && (
            details.map((detail,index)=> (
              <>
              <input checked={detail.isDone} type='checkbox' onClick={()=>handleChange(detail.id)}/>
              <p> {detail.isDone && detail.title} </p>
              </>
            ))
          
        )}
         
            {/* <Contact/> */}
            {/* <Cart/> */}

            {/* <AccordianWidget/> */}

            {/* <DropDown/> */}
            {/* <Board2/> */}
            {/* <InfiniteScrolling/> */}
            {/* <Otpbox/> */}
            {/* <Modal/> */}
            {/* <ImageCarousel/> */}
            {/* <ShoppingList/> */}
            {/* <StarWidget/> */}
            {/* <FAQ/> */}
            {/* <TransferList/> */}
            {/* <Tree/> */}
            {/* <CustomTabs/> */}
            {/* <DragNDrop/> */}
            {/* <TicTacToe/> */}
            {/* <FormValidation/> */}
            {/* <StopWatch/> */}
{/* 
            <div>
          {
            listOne.length > 0 && (
              listOne.map((list,index) => (
                <>
                  <div key={index}> 
                    <input type='checkbox' onClick={()=>handleCheckbox(index)} /> 
                    <span className='list'>{list}</span>
                  </div>
                </>
              ))
            )
          }

        {
            listTwo.length > 0 && (
              listTwo.map((list,index) => (
                <>
                  <div key={index}>
                    <span className='list2'>{list}</span>
                  </div>
                </>
              ))
            )
          }
       
      </div>
      <button onClick={handleSubmit}>Change</button> */}


{/* <div>
            {fields.map((field,index)=>(
              <>
                <input type='text' 
                value={field.value}
                onChange={(e)=>handleInputChange(e,index)}
                />
                <button onClick={()=>handleRemoveField(index)}>Remove</button>
              </>
            ))}
            <button onClick={ ()=> handleAddField()}>Add </button>
            <button onClick = {()=> handleSubmit()}> Submit </button>
          </div> */}

        </>
    )
}





// **AccordianWidget

// const AccordianWidget = () => {
    
//     const [activeIndex,setActiveIndex] = useState(0);

//     const [state,setState] = useState([]);
//     console.log(state,'state')
//     return(
//         <>
//             <Accoridian isActive={activeIndex === 1} onShow = {()=> setActiveIndex(1)} title= 'ACCORDIAN ONE' type='one' 
//             selectedCheckox ={(type) => setState([...state,type])} 
//             removeCheckbox={(type) => setState(state.filter(ty => ty != type)) }> 

//                 Description from one    
//             </Accoridian>
//             <Accoridian isActive={activeIndex === 2} onShow = {()=> setActiveIndex(2)} title= 'ACCORDIAN TWO' type='two' 
//             selectedCheckox ={(type) => setState([...state,type])}
//             removeCheckbox={(type) => setState(state.filter(ty => ty != type)) } >
//                 Description from two
//              </Accoridian>
//             <Accoridian isActive={activeIndex === 3} onShow = {()=> setActiveIndex(3)} title= 'ACCORDIAN THREE' type='three ' 
//             selectedCheckox ={(type) => setState([...state,type])}
//             removeCheckbox={(type) => setState(state.filter(ty => ty != type)) }> 
//                 Description from three
//             </Accoridian>

//             <button disabled={state.length != 3} type='submit'>submit</button>
//         </>
//     )
// }

// const Accoridian = ({isActive,onShow,children,title,type,selectedCheckox,removeCheckbox}) => {

    

//     const handleSelect = (event) => {
  
//         event.stopPropagation();

//         console.log(event.target.value);
//             if(event.target.checked){
//                 console.log(event.target.value,'yo');
//                 selectedCheckox(event.target.value)
//             }else{
//                 removeCheckbox(event.target.value)
//             }
//     }
    

//     return(
//         <>
//             <div className='accordian' onClick={onShow}>
//                     <input type='checkbox' value={type}  onChange={(e)=>handleSelect(e)} />
//                     <h1>Title:- {title}</h1>
//                     {
//                         isActive &&(
//                             <p> Content {children }</p>
//                         )
//                     }
//             </div>
            
//         </>
//     )
// }




// ** tic tac toe 
// const Prac3 = () => {
//     return(
//         <div>
//             <Board/>
//         </div>
//     )
// }

// const Board = () => {
//     const [marks,setMarks] = useState([0,0,0,0,0,0,0,0,0]);
//     const [player,setPlayer] = useState(1);


//     useEffect(()=>{
//         const combinations = [
//             [0,1,2],
//             [3,4,5],
//             [6,7,8],
//             [0,4,8],
//             [2,4,6],
//             [0,3,6],
//             [1,4,7],
//             [2,5,8]
//         ]

//         for(let c of combinations){
//             if(marks[c[0]] === 1 &&  marks[c[1]] === 1 && marks[c[2]] === 1){
//                 alert("player 1 won")
//             }

    
//             if(marks[c[0]] === 2 &&  marks[c[1]] === 2 && marks[c[2]] === 2){
//                 alert("player 2 won")
//             }
//         }
//     },[marks])

//     const changeMarks = (i) => {
//         const m = [...marks];
//         if(m[i] ===0){
//             m[i] = player;
//             setMarks(m)
//             setPlayer(player === 1 ? 2 : 1)
//         }else{
//             alert('click on empty box')
//         }
//     }

//     return(
//         <>
//             <div className='Board'>
//                 <div>
//                     <Block marks={marks[0]} position={0} onClickBox ={()=>changeMarks(0)}/>
//                     <Block marks={marks[1]} position={1} onClickBox ={()=>changeMarks(1)}/>
//                     <Block marks={marks[2]} position={2} onClickBox ={()=>changeMarks(2)}/>
//                 </div>
//                 <div>   
//                      <Block marks={marks[3]} position={3} onClickBox ={()=>changeMarks(3)}/>
//                     <Block marks={marks[4]} position={4} onClickBox ={()=>changeMarks(4)}/>
//                     <Block marks={marks[5]} position={5} onClickBox ={()=>changeMarks(5)}/>
//                 </div>
//                 <div>
//                     <Block marks={marks[6]} position={6} onClickBox ={()=>changeMarks(6)}/>
//                     <Block marks={marks[7]} position={7} onClickBox ={()=>changeMarks(7)}/>
//                     <Block marks={marks[8]} position={8} onClickBox ={()=>changeMarks(8)}/>
//                 </div>

//             </div>
//         </>
//     )
// }


// const Block = ({marks,position,onClickBox}) => {
    
//     return(
//         <>
//             <div className={`Block mark${marks}`} onClick={onClickBox}></div>
//         </>
//     )
// }

// Single Task 
// id,
// title,
// category,

// Multiple task []

// Components - 
//     1. TaskCard (delete icon)
//     2. TaskList
//     3. Form/Modal/Popover 

    // <Tasks/>


// Pagination
// const Prac3 =() => {
//     // https://dummyjson.com/products?limit=100 
//     const [products,setProducts]= useState([]);
//     const [page,setPage] = useState(1);

//     const setPageHandler = (pageIndex) => {
//         console.log('output',pageIndex)
//         if(pageIndex >= 1 && pageIndex < products.length / 10 && page !=pageIndex){
//             setPage(pageIndex);
//             console.log('output')
//         }
//      }


//     async function fetchProducts() {
//         try{
//             const response = await fetch('https://dummyjson.com/products?limit=100');
//             const data  = await response.json();
//             if(data.products.length > 0){
//                 setProducts(data.products)
//                 console.log(data.products,'data')
//             }
//         }
//         catch(e){

//         }
//     }

//     useEffect(()=>{


//         fetchProducts()
//     },[])

//     return(
//         <>
//         <div className='products'>
//             {
//                 products.length > 0 && 
//                     <div className='product'>
//                     {
//                         products.slice(page*10-10,page*10).map(product => (
//                             <div className='product-wrap' key={product.id}>
//                                 <img src={product.images} alt=''/>
//                                 <p>{product.title}</p>
//                             </div>
//                         ))
//                     }
//                     </div>               
//             }
//             {
//                 products.length >   0 && (
//                     <div className='navidgation'>
//                         <button onClick={()=>setPageHandler(page - 1)} className={page > 1 ?  " ": "page-disable"}>Prev</button>
//                         {
//                             [...Array(products.length/10)].map((_,i) => {
//                                 return <span
//                                     className={page == i + 1 ? "page-selected": " "}
//                                     onClick={()=>setPage(i+1)}
//                                     key={i}
//                                     >
//                                         {i+1}
//                                     </span>                    
//                             })
//                         }
//                         <button onClick={()=>setPageHandler(page + 1)} className={page <  products.length ?  " ": "page-disable"}>next</button>
//                     </div>
//                 )
//             }
//         </div>
//         </>   
//     )
// }




// **Modal**
// const Prac3 = () => {
//     const [show,setShow] = useState(false);

//     return(
//         <>
//             <button onClick = {() => setShow(true)}>{show ? 'Hide Button' : 'Show Button'} </button>
//             <Modal show={show} onClose={()=>setShow(false)}> Close Modal </Modal>
//         </>
//     )
// }

// const Modal = ({show,onClose}) => {
    

//     return(
//         <>
//             {
//                 show && (
//                     <div className='modal-background' onClick={onClose}>
//                         <div className='modal-container'>
//                             <div className='modal-wrapper'>
//                                 <p>Title</p>
//                                 <button onClick={onClose}>Close</button>
//                             </div>
//                         </div>
//                     </div>
//                 )
               
//             }
//         </>
//     )
// }





// const useOnlineStatus = () => {
//     const [isOnline,setOnlineStatus] = useState(true);

//     useEffect(()=>{

//         function handleOnline () {
//             setOnlineStatus(true)
//         }

//         function handleOffline ()  {
//             setOnlineStatus(false)
//         }

//         window.addEventListener('online',handleOnline)
//         window.addEventListener('offline',handleOffline)

//         return () => {
//             window.removeEventListener('online',handleOnline)
//             window.removeEventListener('offline',handleOffline)
//         }

//     },[])
    
//     return [isOnline]

// }

// const Prac3  = () => {

//     const [isOnline] = useOnlineStatus()
//     console.log(isOnline,'online')

//     return(
//         <>
//                 <button disabled = {!isOnline}>
//                     Heyy
//                 </button>
//         </>
//     )
// }

// const Prac3 = () => {
//     const [toggle,setToggle] = useState(false)

  
//     useEffect(()=>{
//         console.log('useEffect ran')
//     },[])

//     useLayoutEffect(()=>{
//         console.log('useLayout ran')
//     },[])
//     return(
//         <>
//         {toggle ? <Counter key="counter1"/> : <Counter key="counter2"/>}
//         <button onClick={()=>setToggle(!toggle)}>Toggle</button>
//         </>
//     )
// }

// const Counter = () => {
//     const [counter,setCounter] = useState(0)
//     return(
//         <>  
//         <p>Count {counter}</p>
//             <button onClick={()=>setCounter(count => count + 1)}>UPDATE</button>
//         </>
//     )
// }


// const Prac3 = () => {
//     const [activeIndex,setActiveIndex] = useState(0)
//     return (
//         <>
//             <div className='accordian'>

//                 <Panel 
//                 title='Panel 1' 
//                 isActive={activeIndex ===0}
//                 onShow = {()=> setActiveIndex(0)}
//                 > PANEL One  </Panel>
//                 <Panel 
//                 title='Panel 2'  
//                 isActive={activeIndex ===1}
//                 onShow = {()=> setActiveIndex(1)}
                
//                 > PANEL TWO </Panel>
//             </div>
        
//         </>
//     )
// }

// const Panel = ({title,isActive,onShow,children}) => {
    
//     return(
//         <>
//             <p>{title}</p>
//             {isActive ? (
//                 <p>   {children}</p>
//             ) :(
//                 <button onClick= {onShow}>Click</button>
//             )}
//         </>
//     )
// }


// const Prac3 = () => {


//     const inputRef = useRef(null)
//     const [value,setValue] = useState([])
//     const [count,setCount] = useState(5)

//     const selectedNumber = () => {
//         // if(value.includes(+inputRef.current.value)) return

//         setValue([
//             ...value,
//             +inputRef.current.value
//         ]);
//         setCount(count => count -1)
//     }

//     const selectColorBasedOnNumer = (number) => {
//         console.log(number,'number')
//         switch(number){
//             case 1:
//                 return 'red'
//             case  2:
//                 return 'blue'
//             case  3:
//                 return 'green'
//             case  4:
//                 return 'yellow'
//             case  5:
//                 return 'grey'
//             default:
//                 return 'white'
//         }
 
//     }

//     return(
//         <>
//             <div className='containerWrapper'>
//                 <div className='displayWrapper'>
//                 {
//                         [...value].map((num,i)=> (
//                             <div key={i} className='circle' style={{backgroundColor : selectColorBasedOnNumer(num)}}>

//                             </div>
//                         ))
//                     }
//                 </div>
//                 <div className='circleWrapper'>
//                     {
//                         [...Array(count)].map((_,i)=> (
//                             <div key={i} className='circle' style={{backgroundColor : selectColorBasedOnNumer(i+1)}}>

//                             </div>
//                         ))
//                     }
//                 </div>
//                 <div className='inputWrapper'>
//                     <input type='text' placeholder='Enter Number'  ref={inputRef}/>
//                     <button onClick={selectedNumber}>Click</button>
//                 </div>
//             </div>
        
//         </>
//     )
// }


// ** Table Data ** 
// const tableData =[
//     {
//         name : 'STOCK 3',
//         price : 1000
//     },
//     {
//         name: 'STOCK 1',
//         price : 2000
//     },
//     {
//         name : 'STOCK 2',
//         price : 500
//     }
// ]

// const myReducer = (state,action) => {
//     switch(action.type){

//         case 'sortByName':
//             return {
//                 ...state,
//                 data: [...state.data].sort((a,b) => a.name.localeCompare(b.name)),
//                 sortBy: 'sortByName'
//             }
        
//         case 'sortByPrice' : 
//         return{
//             ...state,
//             data: [...state.data].sort((a,b)=> b.price - a.price),
//             sortBy: 'sortByPrice'
//         }
//         default: 
//         return state
//     }
// } 

// const Prac3 = () => {

//     const [state,dispatch] = useReducer(myReducer,{
//         data: tableData,
//         sortBy: ''
//     })

//     return (
//         <>
//             <table>
//                 <thead>
//                     <th onClick={()=>dispatch({type:'sortByName'})}>
//                         Name
//                     </th>    
//                     <th onClick={()=> dispatch({type:'sortByPrice'})}>
//                         Price
//                     </th>    
         
//                 </thead>    
//                 <tbody>
//                     {
//                         state.data.map((item) => (
//                             <tr>
//                                 <td>Name :- {item.name}</td>
//                                 <td>Price:- {item.price}</td>
//                             </tr>
//                         ))
//                     }
//                 </tbody>
//             </table>      
//         </>
//     )
// }


// **Toggle**
// const Prac3 = () => {
    
//     const [toggle,setToggle] = useState(false);

//     return(
//         <>
//             <div className='Page1'>

//                 <button onClick={()=> setToggle(toggle => !toggle)}/>
//                 <Child1 toggle ={toggle}/>
//             </div>

//         </>
//     )

// }

// const Child1 = ({toggle}) => {
//     return (
//         <>
//             <div className={toggle ? 'darkMode' : 'lightMode'}>
//                 Mode Selection
//             </div>
//         </>
//     )
// }


    // **Slider**
    // const Prac3 = () => {
    //     const images = [
    //         {
    //           image_url:
    //             "https://img.freepik.com/free-photo/young-female-jacket-shorts-presenting-comparing-something-looking-confident-front-view_176474-37521.jpg?w=1800&t=st=1693037944~exp=1693038544~hmac=97e967909706f9b73b4b47d521acf54806f4b9b3efab6196bc8a69f07efff554",
    //           caption: "Image 1"
    //         },
    //         {
    //           image_url:
    //             "https://img.freepik.com/free-photo/girl-grey-shirt-showing-something-her-hand_144627-51099.jpg?t=st=1693037931~exp=1693038531~hmac=63713e5a5cf2d23f53ca82b9996ad224ac6e92d0275a53b6debbe6523d7df020",
    //           caption: "Image 2"
    //         },
    //         {
    //           image_url:
    //             "https://img.freepik.com/free-photo/young-lady-shirt-jacket-making-scales-gesture-looking-cheerful-front-view_176474-85195.jpg?t=st=1693037931~exp=1693038531~hmac=2f83b6689538e4056912c96f448163e9ef10998f48f671b7e50279f81611fbe6",
    //           caption: "Image 3"
    //         },
    //         {
    //           image_url:
    //             "https://img.freepik.com/free-photo/girl-wide-opening-hands-giving-explanation-high-quality-photo_144627-60466.jpg?w=1800&t=st=1693038021~exp=1693038621~hmac=d4520cd86b2aea3e5dda765ede05bb53d70e18a574756d0f41a6806fe325d26d",
    //           caption: "Image 4"
    //         },
    //         {
    //           image_url:
    //             "https://img.freepik.com/free-photo/young-lady-shirt-jacket-making-scales-gesture-looking-cheerful-front-view_176474-85195.jpg?t=st=1693037931~exp=1693038531~hmac=2f83b6689538e4056912c96f448163e9ef10998f48f671b7e50279f81611fbe6",
    //           caption: "Image 5"
    //         },
    //         {
    //           image_url:
    //             "https://img.freepik.com/free-photo/girl-wide-opening-hands-giving-explanation-high-quality-photo_144627-60466.jpg?w=1800&t=st=1693038021~exp=1693038621~hmac=d4520cd86b2aea3e5dda765ede05bb53d70e18a574756d0f41a6806fe325d26d",
    //           caption: "Image 6"
    //         }
    //       ];

    //       const [active,setActive] = useState(1);
    //       const [items,setItems] = useState(images);

    //       const onPrev  = () => {
    //             if(active>0){
    //                 setActive(active-1);
    //             }
    //       }

    //       const onNext = () =>{
    //         if(active < images.length-1){
    //             setActive(active + 1)
    //         }
    //       }
    //       return (
    //         <>
    //                 <div className='slider'>
    //                     {
    //                         items.map((item,index)=>(
                 
    //                                 <Slide key={item.caption} {...item} active={active === index}/>
                             
    //                         ))
    //                     }
                        
    //                 </div>  
    //                 <div className='navigation'>
    //                         <div className='next-prev prev' onClick={onPrev}></div>
    //                         <div className='next-prev    ' onClick={onNext}></div>
    //                 </div>

    //         </>
    //       )
    // }

    // const Slide = ({image_url,caption,active}) => {
    //     return(
    //         <>
    //         <div className={`slide ${active ? "active" : '' }`}>
    //             <img src={image_url} alt={caption}/>
    //             <p>caption</p>
    //             </div>
    //         </>
    //     )
    // }


// **input suggestions**
// const Prac3 = () => {
//     const [suggestion,setSuggetions] = useState(['A','B','C','D','E','F','G','H','ABC']);
//     const [inputValue,setValue] = useState('');

//     const handleChange = (e)=> {
//         const value = e.target.value;
//         setValue(value);

//         let filterSuggestion = suggestion.filter((ele) => ele.toLowerCase().includes(value.toLowerCase()));
//         console.log(filterSuggestion)
//         setSuggetions(filterSuggestion)
//     }
 
//     return(
//         <>
//             <input
//                 value={inputValue}
//                 onChange={handleChange}
//                 placeholder='Type Here Something..'
//             />    
            
//             {
//                 inputValue && suggestion.length > 0 && (
//                     <ul>
//                         {
//                             suggestion.map((item,index) =>{
//                               return  <li key={index}> {item}</li>
//                             })
//                         }
//                     </ul>
//                 )
//             }
//         </>
//     )
// }




// const colorSelection = (index) => {
//     switch(index){
//         case 2 : 
//         return "red"
//         default:
//         return "no color"
//     }

// }


// const Prac3 = () => {

//     return(
//         <>
//             {
//                     [Array.from({length:5})].map((_,i)=>{
//                         return <div className='wrp' key={i}>
//                             <p>FIRST{i}</p>
//                             <p>Hello</p>
//                         </div>
//                     })
//                 }   
//                 {
//                     [...Array(5)].map((_,i)=>{
//                         return <div className='wrp' key={i} style={{backgroundColor: colorSelection(i)}}>
//                             <p>Index {i}</p>
//                             <p>Hello</p>
//                         </div>
//                     })
//             }
//             {
//                 <div>GOOD</div>
//             }
//         </>
//     )
// }



// **Pagination**
// const Prac3 = () => {
//     const [page,setPage] = useState(1);
//     const [products,setProducts] = useState([])

//     useEffect(()=>{

//         const fetchProducts =async () => {
//             const response = await fetch('https://dummyjson.com/products?limit=100');
//             const responseJson = await response.json();
            
//             setProducts(responseJson.products)
//         }

//         fetchProducts()
//     },[])

//     const selectedPageHandler = (selectedPage) => {
//         if( selectedPage !== page && selectedPage >= 1 && selectedPage <= products.length/10){
//             setPage(selectedPage)
//         }
//     }

//     return(
//         <>
//             {
//                 products.length > 0  &&
//                 <div className='prodcuxts'>
//                     {
//                         products.slice(page * 10 - 10,page* 10).map((prod) => {
//                             return ( 
//                                 <span className='products__single' key={prod.id}>
//                                   <img src={prod.thumbnail} alt={prod.title}/>
//                                   <span>{prod.title}</span>
//                                 </span>
//                                 )
//                         })
//                     }
//                 </div>

//             }
//             {
//                 products.length > 0 && <div className='pagination'>

//                     <span onClick={()=>selectedPageHandler(page - 1)} className={page > 1 ? " " : "pagiantion_disale"}>back</span>
//                     {
//                         [...Array[products.length/10]].map((_,i)=>{
//                             return <span
//                                 className={page === i + 1 ? "pagination_selected": ""}
//                                 onClick={()=>selectedPageHandler(i+1)}
//                                 key={i}>{i+1}</span>
                        
//                         })
//                     }
//                     <span onClick={()=>selectedPageHandler(page - 1)} className={page < products.length - 1 ? " " : "pagiantion_disale"}>forward</span>
//                 </div>
//             }
        
//         </>
//     )
// }



// **UseMemo**

// const Prac3 = () => {

//     const [state,setState] = useState(0);

//     let obj = useMemo(()=>{
//         return {value: 1}
//     },[])

//     return(
//         <>
        
//             <Child1 obj={obj} name='prath'/>
//             <Child2/>
//             <button onClick={()=>setState(count => count +1)}>Click Here</button>
//         </>
//     )
// }

// const Child1 = memo(({obj,name}) => {
//     console.log("render1")
//     return(
//         <>
        
//         </>
//     )
// })

// const Child2 = () => {
//     console.log("render2")
//     return(
//         <>
//         </>
//     )
// }



// **CONTEXT API + REDUCER **

// const CounterContext = createContext(null)


// const Prac3 = () => {

//     const myReducer = (state,action) => {

//         switch(action.type){
//             case "increament" : 
//                 return state+1;
//             case "decreament" :
//                 return state - 1;
//             default: 
//             throw new Error('not found')
//         }
//     }

//     const [state,dispatch] = useReducer(myReducer,0);



//     return(
//         <>
//         <CounterContext.Provider value = {{state,dispatch}}> 
//             <Child />
//         </CounterContext.Provider>
//         </>
//     )
// }

// const Child = () => {
//     const {state,dispatch} = useContext(CounterContext)
//     return(
//         <>
//             <button onClick={()=>dispatch({type: "increament"})}>Increament</button>
//             <button onClick={()=>dispatch({type: "decreament"})}>decreament</button>
//             <p>Counter: {state}</p>
//         </>
//     )
// }


// **Controlled Forms**
// const Prac3 = () => {
//     const [data,setData] = useState({
//         name:'',
//         email: '',
//     })

//     const handleClick = () => {
//         console.log(data)
//     }

//     const handleChange = (event) => {
//         setData({
//             ...data,
//             [event.target.name]: event.target.value
//         })
//     }

//     return(
//         <>
//                 <input type='text' name='name' value={data.name} placeholder='Enter a Name' onChange={(event) => handleChange(event)} />
//                 <input type='email' name='email' value={data.email} placeholder='Enter a Email' onChange={(event) => handleChange(event)}/>
//                 <button onClick={()=>handleClick()}>Click Here</button>
//         </>
//     )

// }

// **Api Fetch Call**

// const Prac3 = () => {
//     const [data,setData] = useState(null);
//     const [loading,setLoading] = useState(true);
//     const [error,setError] = useState(false);
    

//     async function fetchDetails(){
//         try{
//             const response = await fetch('https://jsonplaceholder.typicode.com/todos/1');
//             const responseJon = await response.json();

//             setLoading(false);
//             setData(responseJon)
//         }
//         catch(e){
//             setError('error')
//             setLoading(false)
//         }
//     }
//     useEffect(()=>{

//         fetchDetails()
//     },[])

//     return (
//         <>
//             {loading && <p>Loading</p>}
//             {error && <p>Error</p>}
//             {data && <p>{data.title}</p>}

//         </>
//     )
// }


// **Render Prop Pattern** 

// const Prac3 = () => {

//     return (
//         <>
//         <UserDetails 
//             fetchData = {async () => await fetch('https://jsonplaceholder.typicode.com/todos/1')}
//             render={(props) =>(
//                 <div>
//                 <p>Title {props.title}</p>
//                 <p>Id {props.id}</p>
//                 </div>
//             )}
//         />

//         </>
//     )
// }

// const UserDetails = ({fetchData,render}) => {
//     const [data,setData] = useState(null);


//     useEffect(()=>{
//         async function callApi(){
//             const response = await fetchData();
//             const responseJson = await response.json();
//             setData(responseJson)
//         }
//         callApi()
//     },[])

//     return(
//         <>
//             <p>User Details</p>
//             <p>{ data && render(data)}</p>
//         </>
//     )
// }


// **Accordian**

// const Prac3 = () => {



//     return (
//         <>  
//                         <AccorianWidget defaultIndex = '1'>

//                             <AccordianItem label = 'A' index = '1'> ITEM 1</AccordianItem>
//                             <AccordianItem label = 'B' index = '2'> ITEM 2</AccordianItem>    
//                         </AccorianWidget> 
//         </>
//   )
// }

// const AccorianWidget = ({defaultIndex,children}) => {

//         const [bindIndex,setBindIndex] = useState(defaultIndex);

//         const changeIndex = (itemIndex) => {
//             console.log(itemIndex,'index')
//             if(itemIndex !== bindIndex) setBindIndex(itemIndex)
//         }

//         const item = children.filter((item) => item.type.name === 'AccordianItem')

//         return(
//             <>
//             {item.map(({props})=>{
                    
//                    return <AccordianItem 
//                         key = {props.index}
//                         isCollaspsed = {bindIndex !== props.index}
//                         label = {props.label}
//                         handleClick ={() => changeIndex(props.index)}
//                         children = {props.children}
//                     />
//             })}

            
//             </>
//         )
// }

// const  AccordianItem = ({isCollaspsed,label,handleClick,children}) => {
//     return(
//         <>
//             <button className='accordian-btn' onClick={() => handleClick()}>{label}</button>
//             <div className={`accordian-item ${isCollaspsed ? 'collapsed' : 'expanded'} `}>
//                 {children}
//             </div>
//         </>
//     )
// }

export default Prac3