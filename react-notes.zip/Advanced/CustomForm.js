

import React, { useState } from 'react'


const useForm = (initialState) => {
    const [values,setValue] = useState(initialState);

    function updateValue(event,reset){
           if(reset ==="empty") setValue(initialState)
           else{
            setValue({
                ...values,
                [event.target.name]  :event.target.value
             })
           }
            
    }

    return[
        values,
        updateValue
    ]
}

const CustomForm = () => {
    const initialState = {email:'',password:''};
    const [value,updateValue] = useForm(initialState);

    const handleSubmit = (event) =>{
        event.preventDefault();
        console.log(value,'output')
        updateValue(event,"empty")
    }
    return (
        <>
            <form>
                <input type='email' name='email' placeholder='Enter Email Here' onChange={updateValue} value={value.email}/>
                <input type='password' name='password' placeholder='Enter Password Here' onChange={updateValue} value={value.password}/>
                <button  onClick={handleSubmit}>Submit</button>
            </form>    
        </>
    )
}

export default CustomForm