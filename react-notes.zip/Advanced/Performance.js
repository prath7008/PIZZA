import React, { useCallback, useMemo, useState } from 'react'

const Performance = () => {
    const [counter,setCounter] = useState(0)
    
    let obj = useMemo(()=>{
        return {value: "STRING"}
    },[]);

    const onClick = useCallback(()=>{
        setCounter(counter => counter +1)
    },[])

    return (
    <>

        <p>{counter}</p>
        {/* <ChildMemo obj= {value: "STRING"} onClick={onClick}/> */}
        <ChildMemo obj= {obj} onClick={onClick}/>
    </>
  )
}

const Child = ({obj,onClick}) => {

    console.log("Render")

    return(
        <>
        <button onClick={onClick}>Update</button>

        <p>{obj.value}</p>
        </>
    )
}

const ChildMemo = React.memo(Child)

export default Performance