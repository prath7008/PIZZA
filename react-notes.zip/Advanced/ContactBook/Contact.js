import { useEffect, useState } from "react";



const Contact = () => {

    const [contactbook,setContactBook] = useState([
        {id: 1, name: 'RAHUL',city: 'MUMBAI'},
        {id: 2, name: 'PRATH', city: 'DELHI'},
        {id: 3, name: 'RAKESH',city: 'BANGALRE'},
    ])

    const [editform,setEditForm] = useState(false);
    
    const [editContact,setEditContact] = useState({
        name:'',
        city: ''
    })

    const handleEdit = (contact) => {
        setEditForm(true)
        setEditContact(contact)
    }


    const handleDelete = (contact) => {
        setContactBook(contactbook.filter((cont)=> cont.id != contact.id))
    }

    const updateContactBook = (data) => {
        setContactBook([
            ...contactbook,
            {
                id: contactbook.length+1,
                name: data.name,
                city : data.city
            }
          
        ])
    }

    const updateEditContact = (data) => {
    
        const findContactByIndex = contactbook.findIndex(contact => contact.id === data.id);
        console.log(data,findContactByIndex,'data')
        const newcontactbook = [...contactbook]
        newcontactbook.splice(findContactByIndex,1,data)
        
        setContactBook(newcontactbook)
        setEditForm(false)
        setEditContact({
            name:'',
            city: ''
        })
    }

    return(
        <>
        <FormChange editContact={editContact}  editform={editform} updateContactBook={updateContactBook} updateEditContact={updateEditContact}   /> 

            <div className='display-wrapper'>
                {
                    contactbook.map((contact) => (
                        <div className="contact-wrap" key={contact.id}>
                            <p>Name :- {contact.name}</p>
                            <p>Contact:- {contact.city}</p>
                            <button onClick={()=>handleEdit(contact)}>Edit</button>
                            <button onClick={()=>handleDelete(contact)}>Delete</button>
                        </div>
                    ))
                }
            </div>
        </>
    )
}

const FormChange =({editContact,updateContactBook,editform,updateEditContact}) => {

 
    const [state,setState] = useState({
        name:'',
        city: ''
    });

    useEffect(()=>{
        setState(editContact)
    },[editContact])

    console.log(editContact,state,'edit')

    const handleFormChange = (event) => {  
        setState({
            ...state,
            [event.target.name] : event.target.value
        })

    }

    const resetForm = () => {
        setState({
             name:'',
             city: ''
        })
    }

    const submitForm = (event) => {
        event.preventDefault()
        if(editform){
            updateEditContact(state)
        }else{
            updateContactBook(state)
        }
        resetForm()
    }
    
    return(
        <>  
                        <form onSubmit={submitForm}>
                            <label htmlFor="Name">Name</label>
                            <input type="text" name='name' value={state.name} placeholder="Enter Your Name" onChange={handleFormChange}/>
                            <label htmlFor="City">City </label>
                            <input type="text" name='city' value={state.city} placeholder="Enter Your City" onChange={handleFormChange}/>
                            <button type="submit">{editform ? 'EDIT CONTACT' : 'ADD CONTACT'}</button>
                        </form>
                

        </>
    )
}

export default Contact