import React, {  useEffect, useState } from 'react'

// const dataPromise = async(query) => await fetch(
//     `https://swapi.dev/api/people/?search=${query}`
//   )
 
const Prac = () => {

    return(
        <>
        
            <InputSearch 
                id='input'
                placeholder = 'Enter Text Here'
                noItem = {()=><h2>No Item Present</h2>}
                error = {()=><h2>Error Message Present</h2>}
                listBox = {(data) => <ListBox data={data}/>}
            />
        </>
    )
}

const ListBox = ({data}) => {
    console.log(data,'Items')
    return(
        <>
            <ul>
                {data.map((item,index)=> <li key={index}>{item.name}</li>)}
            </ul>
        </>
    )
}

const useFetchPromise = (query) => {
    const [data,setData] = useState(null);
    const [error,setError] = useState(null);
    
    const dataPromise = async(query) =>{
      try{
            let response   =  await fetch(`https://swapi.dev/api/people/?search=${query}`);
            let responseJson = await response.json();
            setData(responseJson.results)
        }
        catch(error){
            setError(error)
        }
    } 

    useEffect(()=>{
        if(!query){
            setData(null);
            setError(null);
            return
        }

        dataPromise(query)
    },[query])

    return [data,error]
}


const InputSearch = ({id,placeholder,noItem,err,listBox}) => {

    const [data,setData] = useState(null);

    const [result,error] = useFetchPromise(data);

    console.log(result,'result')
    
    const handleChange = (event) => {
        setData(event.target.value)
    }

    console.log(result)
    return(
        <>
            <input 
                id={id}
                placeholder={placeholder}
                onChange = {(event)=> handleChange(event)}      
            />
            {error && err()}  
            {result && !result.length && noItem()}
            {result && result.length > 0 && listBox(result)}
        </>
    )
}


export default Prac