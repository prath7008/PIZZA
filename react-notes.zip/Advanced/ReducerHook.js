import { useReducer } from "react"



const myReducer = (state,action)=>{

    switch(action.type){

        case 'INCREAMENT': 
            return {counter: state.counter + action.payload}

        case 'DECREAMENT':
            return {counter: state.counter - action.payload}

        default:
            return state
    }
}


const ReducerHook = () => {
    const [state,dispatch] = useReducer(myReducer,{counter:0});

    return(
        <>
           <p>Counter {state.counter}</p> 
            <button onClick={()=>dispatch({type:'INCREAMENT',payload:1})}>Increament</button>
            <button onClick={()=>dispatch({type:'DECREAMENT',payload:1})}>Decreament</button>
        </>
    )
}


export default ReducerHook




