import  {useState,useRef} from 'react'

//addtodo,edittodo,deletetodo

const Todo = () => {
        const [todos,setTodos]  = useState([
            { id: 1, text : 'FIRSTT' }, 
            {id : 2 , text: 'SECONDD' }, 
            {id : 3 , text : 'THIRDD'}
        ]);

        const handleAddTodo = (value) => {
            setTodos([
                ...todos,
                {
                    id: todos.length +1,
                    text: value
                }
            ])
        }
        const handleEditTodo = () => {
            
        }
        const handleDeleteTodo = (id) => {
                   
                    let newTodos = todos.filter( (todo) => todo.id !== id )
                    setTodos(newTodos)
        }

    return(
        <>
            <Addtodo onAdd = {handleAddTodo}/>
             {todos.map((todo) => (
                <DisplayTodo 
                    key  = {todo.id}
                    todo ={todo}
                    onEdit={handleEditTodo}
                    onDelete = {handleDeleteTodo}
                />
            ))}       
        </>
    )        
}

const DisplayTodo = ({todo,onEdit,onDelete}) => {
    const [editForm,setEditForm] = useState(false);

    const handleEdit = () => {
            setEditForm(prevState => !prevState);
    }

    const handleCancel = () => {
        setEditForm(prevState => !prevState)
    }

    const handleSave = () => {
        
    }
    
    return(
        <>
            {
                editForm ?  (
                    <EditForm 
                        onEdit ={onEdit}
                        onSave = {handleSave}
                        onCancel  = {handleCancel}
                        todo={todo}                
                    />
                ): (            
                    <>
                            <p>Todo Text :- {todo.text}</p>
                            <button onClick ={()=>onDelete(todo.id)}>Delete </button>
                            <button onClick ={() => handleEdit()}>Edit</button>
                    </>
              
                )
            }
        </>
    )
}

const EditForm  = (onEdit,onSave,onCancel,todo) => {
    const inputRef = useRef(0);

     const handleSave =(id) => {
             onSave(id,inputRef.current.value)
     }
    return(
        <>
                <form type="submit">
                    <input ref={inputRef} type="text" placeholder='EnterTextHere'/>
                           <button onClick ={()=>handleSave(todo.id)}> Save</button>
                            <button onClick ={() => onCancel()}>Cancel</button>
                </form>
        </>
    )
}

const Addtodo = ({onAdd}) => {
    const [inputvalue,setInputVal] = useState('');

    const handleAddTodo = () => {
                onAdd(inputvalue)
    }

    
    return(
        <>
            <input type="text" placeholder="Enter Text here" onChange={(e)=>setInputVal(e.target.value)} value ={inputvalue} />
            <button onClick={ ()=>handleAddTodo()}> Add </button>
        </>
    )
}



export default Todo