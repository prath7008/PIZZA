import React, { useEffect, useState } from 'react';
import './FAQ.css';



const FAQ = () => {

    const faqs = [
        {
          question: "How many bones does a cat have?",
          answer: "A cat has 230 bones - 6 more than a human",
        },
        {
          question: "How much do cats sleep?",
          answer: "The average cat sleeps 12-16 hours per day",
        },
        {
          question: "How long do cats live",
          answer: "Outdoor cats live 5 years on average. Indoor\ncats live 15 years on average.",
        },
      ]
  
  return (
    <>
    {
        faqs.map((faq,index)=> (
             <FAQItem faq={faq} index={index} />
        ))
    }
    </>
  )

}


const FAQItem = ({faq,index}) => {
    const [isShow,setIsShow] = useState(false);

    useEffect(()=>{
        if(index===0){
            setIsShow(true)
        }
    },[])

    const handleClick = () => {
        setIsShow((isShow) => !isShow)
    }

    return(
        <>
            <div className='faq-box'>
                <div className='que' onClick={handleClick}>
                    <button className={isShow ? 'arrow': ''}>></button>
                    <div>{faq.question}</div>
                </div>
               {isShow &&  <div className='ans'> {faq.answer}</div>}
            </div>
        </>
    )
}

export default FAQ