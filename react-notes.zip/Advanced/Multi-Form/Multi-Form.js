import React,{useState,useEffect} from "react";
import "./style.css";



function MultiForm() {
    
  const [fields,setFields] = useState([
    {
      name: 'email',
      value:'',
      placeholder: 'Enter Email Here',
      type: 'email'
    },
    {
      name: 'name',
      value:'',
      placeholder: 'Enter Name Here',
      type: 'name'
    },
    {
      name: 'password',
      value: '',
      placeholder: 'Enter Password Here',
      type: 'password'
    }
  ])

  const [index,setIndex] = useState(0)

  const handlePrev = () => {
      if(index == 0){

      }else{
        setIndex(prevIndex => prevIndex - 1) 
      }
  }

  const handleNext = () => {
    if(index === fields.length - 1) {
      
    }else{
      setIndex(prevIndex => prevIndex + 1) 
    }
  }
  
  return (
    <div>
        <button onClick={handlePrev}>back</button>
        {
          fields.slice(index,index+1).map((field)=>(
            <input type={field.type} name={field.name} placeholder={field.placeholder} value={field.value}/>
          ))
        }
        <button  onClick={handleNext}>{index === fields.length - 1 ? 'submit' : 'next'}</button>
    </div>
  );
}





export default MultiForm


