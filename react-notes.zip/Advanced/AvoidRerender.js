import React, { useState } from 'react'

const AvoidRerender = () => {

  return (
    <>
        <ComponentWithScroll>
            <SlowComponent/>
        </ComponentWithScroll>
    </>
  )
}


const SlowComponent = () => {
    console.log("Render")
    return(
        <>
            <p>Slow</p>
        </>
    )
}

const ComponentWithScroll = ({children}) => {
    const [scrollY,setScrollY] = useState(0);
    return(
        <>
            <div onScroll={({currentTarget}) => setScrollY(currentTarget.scrollTop)}>
                {children}
            </div>
        </>
    )
}

export default AvoidRerender